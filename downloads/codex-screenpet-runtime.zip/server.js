"use strict";

var http = require("http");
var childProcess = require("child_process");
var crypto = require("crypto");
var fs = require("fs");
var net = require("net");
var os = require("os");
var path = require("path");
var querystring = require("querystring");

var PORT = Number(process.env.PORT || 8788);
var HOST = process.env.HOST || "0.0.0.0";
var ROOT = __dirname;
var PUBLIC_DIR = path.join(ROOT, "public");
var PACKAGE_FILE = path.join(ROOT, "package.json");
var DATA_DIR = path.join(ROOT, "data");
var STATUS_FILE = path.join(DATA_DIR, "status.json");
var TASKS_FILE = path.join(DATA_DIR, "tasks.json");
var INSTRUCTIONS_FILE = path.join(DATA_DIR, "instructions.json");
var AUTH_FILE = path.join(DATA_DIR, "auth.json");
var SETUP_PREFS_FILE = path.join(DATA_DIR, "setup.json");
var CODEX_STATE_DB = process.env.CODEX_STATE_DB || path.join(os.homedir(), ".codex", "state_5.sqlite");
var CODEX_LOGS_DB = process.env.CODEX_LOGS_DB || path.join(os.homedir(), ".codex", "logs_2.sqlite");
var CODEX_BIN = process.env.CODEX_BIN || "/Applications/Codex.app/Contents/Resources/codex";
var RECENT_LIMIT = Number(process.env.RECENT_LIMIT || 12);
var TASK_TITLE_LIMIT = Number(process.env.TASK_TITLE_LIMIT || 160);
var CODEX_THREAD_TITLE_TTL_MS = Number(process.env.CODEX_THREAD_TITLE_TTL_MS || 1000);
var CODEX_THREAD_TITLE_WAIT_MS = Number(process.env.CODEX_THREAD_TITLE_WAIT_MS || 1200);
var CODEX_THREAD_TITLE_LIMIT = Number(process.env.CODEX_THREAD_TITLE_LIMIT || Math.max(80, RECENT_LIMIT * 4));
var CODEX_THREAD_TITLE_TIMEOUT_MS = Number(process.env.CODEX_THREAD_TITLE_TIMEOUT_MS || 3000);
var ACTIVE_WINDOW_SECONDS = Number(process.env.ACTIVE_WINDOW_SECONDS || 15);
var STALE_OPEN_TURN_SECONDS = Number(process.env.STALE_OPEN_TURN_SECONDS || 7200);
var CODEX_DELIVERY_TIMEOUT_MS = Number(process.env.CODEX_DELIVERY_TIMEOUT_MS || 20000);
var CODEX_DESKTOP_SYNC = process.env.CODEX_DESKTOP_SYNC !== "0";
var DESKTOP_SYNC_THROTTLE_MS = Number(process.env.DESKTOP_SYNC_THROTTLE_MS || 1500);
var DESKTOP_SYNC_COMPLETE_TIMEOUT_MS = Number(process.env.DESKTOP_SYNC_COMPLETE_TIMEOUT_MS || 90000);
var DESKTOP_SYNC_FORCE_REFRESH = process.env.DESKTOP_SYNC_FORCE_REFRESH === "1";
var DESKTOP_SYNC_FALLBACK_FORCE_REFRESH = process.env.DESKTOP_SYNC_FALLBACK_FORCE_REFRESH === "1";
var DESKTOP_SYNC_FORCE_REFRESH_DELAY_MS = Number(process.env.DESKTOP_SYNC_FORCE_REFRESH_DELAY_MS || 650);
var DESKTOP_SYNC_SECOND_OPEN = process.env.DESKTOP_SYNC_SECOND_OPEN !== "0";
var DESKTOP_SYNC_SECOND_OPEN_DELAY_MS = Number(process.env.DESKTOP_SYNC_SECOND_OPEN_DELAY_MS || 1800);
var DESKTOP_SYNC_OPEN_DELAYS_MS = parseDelayList(process.env.DESKTOP_SYNC_OPEN_DELAYS_MS || "0,900,2200,4200");
var DESKTOP_SYNC_INVALIDATE_DELAYS_MS = parseDelayList(process.env.DESKTOP_SYNC_INVALIDATE_DELAYS_MS || "120,1100,2800");
var DESKTOP_SYNC_HARD_RELOAD = process.env.DESKTOP_SYNC_HARD_RELOAD === "1";
var DESKTOP_SYNC_HARD_RELOAD_DELAY_MS = Number(process.env.DESKTOP_SYNC_HARD_RELOAD_DELAY_MS || 950);
var CODEX_DESKTOP_IPC_SYNC = process.env.CODEX_DESKTOP_IPC_SYNC !== "0";
var CODEX_DESKTOP_IPC_SOCKET = process.env.CODEX_DESKTOP_IPC_SOCKET || defaultCodexIpcSocket();
var CODEX_DESKTOP_IPC_TIMEOUT_MS = Number(process.env.CODEX_DESKTOP_IPC_TIMEOUT_MS || 2200);
var CODEX_DESKTOP_FOLLOWER_DELIVERY = process.env.CODEX_DESKTOP_FOLLOWER_DELIVERY === "1";
var CODEX_DESKTOP_FOLLOWER_FALLBACK = process.env.CODEX_DESKTOP_FOLLOWER_FALLBACK !== "0";
var CODEX_CONFIRMED_RPC_FALLBACK = process.env.CODEX_CONFIRMED_RPC_FALLBACK !== "0";
var CODEX_DESKTOP_IPC_REQUEST_TIMEOUT_MS = Number(process.env.CODEX_DESKTOP_IPC_REQUEST_TIMEOUT_MS || 6500);
var DESKTOP_FOLLOWER_OPEN_DELAY_MS = Number(process.env.DESKTOP_FOLLOWER_OPEN_DELAY_MS || 950);
var CODEX_DESKTOP_UI_DELIVERY = process.env.CODEX_DESKTOP_UI_DELIVERY !== "0";
var CODEX_BACKGROUND_DELIVERY_FALLBACK = process.env.CODEX_BACKGROUND_DELIVERY_FALLBACK === "1";
var CODEX_ACTIVE_TURN_QUEUE_TIMEOUT_MS = Number(process.env.CODEX_ACTIVE_TURN_QUEUE_TIMEOUT_MS || 20 * 60 * 1000);
var STARTUP_QUEUED_RESUME_WINDOW_MS = Number(process.env.STARTUP_QUEUED_RESUME_WINDOW_MS || 2 * 60 * 60 * 1000);
var DESKTOP_UI_OPEN_DELAY_MS = Number(process.env.DESKTOP_UI_OPEN_DELAY_MS || 1600);
var DESKTOP_UI_SEND_TIMEOUT_MS = Number(process.env.DESKTOP_UI_SEND_TIMEOUT_MS || 8000);
var DESKTOP_UI_CONFIRM_TIMEOUT_MS = Number(process.env.DESKTOP_UI_CONFIRM_TIMEOUT_MS || 10000);
var DESKTOP_UI_COMPOSER_X_RATIO = Number(process.env.DESKTOP_UI_COMPOSER_X_RATIO || 0.42);
var DESKTOP_UI_COMPOSER_Y_OFFSET = Number(process.env.DESKTOP_UI_COMPOSER_Y_OFFSET || 92);
var SNIPPET_LIMIT = Number(process.env.SNIPPET_LIMIT || 15);
var SNIPPET_TEXT_LIMIT = Number(process.env.SNIPPET_TEXT_LIMIT || 480);
var DETAIL_MESSAGE_TEXT_LIMIT = Number(process.env.DETAIL_MESSAGE_TEXT_LIMIT || 12000);
var DEMO_MODE = process.env.DEMO_MODE === "1";
var PUBLIC_DEMO_ASSETS = process.env.SCREENPET_PUBLIC_DEMO === "1";
var DEMO_TASKS_FILE = process.env.DEMO_TASKS_FILE || path.join(ROOT, "examples", "demo-tasks.json");
var PET_AUTH_ENABLED = process.env.PET_AUTH !== "0";
var PET_AUTH_PIN = String(process.env.PET_AUTH_PIN || process.env.CODEX_PET_PIN || "").trim();
var recentCodexCache = {
  checkedAt: 0,
  tasks: []
};
var activeThreadIdsCache = {
  checkedAt: 0,
  ids: {}
};
var rolloutActivityCache = {};
var rolloutMessagesCache = {};
var codexThreadTitleCache = {
  checkedAt: 0,
  loading: null,
  missingLoading: null,
  reading: {},
  titles: {},
  error: ""
};
var codexRpc = null;
var desktopSyncs = {};
var desktopSyncTimers = {};
var authConfigCache = null;
var deviceNameCache = "";
var networkHardwarePortCache = null;
var MENU_PERMISSION_STATUS_FILE = path.join(os.homedir(), "Library", "Application Support", "Codex ScreenPet", "runtime", "data", "remote-control-permission.json");
var LOCAL_PERMISSION_STATUS_FILE = path.join(DATA_DIR, "remote-control-permission.json");
var remoteControlPermissionCache = {
  checkedAt: 0,
  value: null
};
var startupAt = new Date().toISOString();

var states = {
  idle: true,
  thinking: true,
  working: true,
  waiting: true,
  done: true,
  error: true,
  offline: true
};

var defaultStatus = {
  state: "idle",
  title: "Blinky Codex ScreenPet",
  task: "Waiting for task",
  message: "Ready",
  detail: "Blinky watches your Codex tasks blink by blink.",
  progress: 0,
  updatedAt: new Date().toISOString(),
  startedAt: new Date().toISOString()
};

function parseDelayList(value) {
  var parts = String(value || "").split(/[, ]+/);
  var out = [];
  var i;
  var delay;

  for (i = 0; i < parts.length; i += 1) {
    if (!parts[i]) {
      continue;
    }
    delay = Number(parts[i]);
    if (!isNaN(delay) && delay >= 0) {
      out.push(Math.floor(delay));
    }
  }

  if (!out.length) {
    out.push(0);
  }

  return out;
}

function defaultCodexIpcSocket() {
  var uid;
  if (process.platform === "win32") {
    return "\\\\.\\pipe\\codex-ipc";
  }
  uid = typeof process.getuid === "function" ? process.getuid() : "";
  return path.join(os.tmpdir(), "codex-ipc", uid ? "ipc-" + uid + ".sock" : "ipc.sock");
}

function ensureDataDir() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
}

function authConfig() {
  var raw;
  var parsed;
  var pin;
  var createdAt;
  var custom;

  if (authConfigCache) {
    return authConfigCache;
  }

  if (!PET_AUTH_ENABLED) {
    authConfigCache = {
      enabled: false,
      pin: "",
      source: "disabled",
      generated: false
    };
    return authConfigCache;
  }

  if (PET_AUTH_PIN) {
    authConfigCache = {
      enabled: true,
      pin: PET_AUTH_PIN,
      source: "env",
      generated: false
    };
    return authConfigCache;
  }

  ensureDataDir();

  try {
    raw = fs.readFileSync(AUTH_FILE, "utf8");
    parsed = JSON.parse(raw);
    pin = String(parsed.pin || "").trim();
    createdAt = parsed.createdAt || "";
    custom = !!parsed.custom;
  } catch (err) {
    pin = "";
    createdAt = "";
    custom = false;
  }

  if (!pin) {
    pin = generatePin();
    fs.writeFileSync(AUTH_FILE, JSON.stringify({
      pin: pin,
      createdAt: new Date().toISOString()
    }, null, 2), { mode: 0o600 });
    authConfigCache = {
      enabled: true,
      pin: pin,
      source: "local",
      generated: true,
      custom: false
    };
    return authConfigCache;
  }

  authConfigCache = {
    enabled: true,
    pin: pin,
    source: "local",
    generated: false,
    custom: custom,
    createdAt: createdAt
  };
  return authConfigCache;
}

function setLocalAuthPin(pin) {
  var config = authConfig();
  var previous = {};
  var cleaned = cleanAuthPin(pin);

  if (!config.enabled) {
    return {
      ok: false,
      status: 400,
      error: "Phone password is disabled for this run."
    };
  }

  if (config.source === "env") {
    return {
      ok: false,
      status: 409,
      error: "Phone password is configured with PET_AUTH_PIN."
    };
  }

  if (!cleaned.ok) {
    return {
      ok: false,
      status: 400,
      error: cleaned.error
    };
  }

  ensureDataDir();

  try {
    previous = JSON.parse(fs.readFileSync(AUTH_FILE, "utf8"));
  } catch (err) {
    previous = {};
  }

  fs.writeFileSync(AUTH_FILE, JSON.stringify({
    pin: cleaned.pin,
    createdAt: previous.createdAt || new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    custom: true
  }, null, 2), { mode: 0o600 });

  authConfigCache = {
    enabled: true,
    pin: cleaned.pin,
    source: "local",
    generated: false,
    custom: true,
    createdAt: previous.createdAt || new Date().toISOString()
  };

  return {
    ok: true,
    auth: authPublicState(true)
  };
}

function cleanAuthPin(pin) {
  var value = String(pin || "").trim();

  if (!/^[0-9]{6}$/.test(value)) {
    return {
      ok: false,
      error: "Use exactly 6 digits."
    };
  }

  return {
    ok: true,
    pin: value
  };
}

function readSetupPrefs() {
  var parsed;

  ensureDataDir();
  try {
    parsed = JSON.parse(fs.readFileSync(SETUP_PREFS_FILE, "utf8"));
  } catch (err) {
    parsed = {};
  }

  return {
    manualTunnelUrl: cleanSetupTunnelUrl(parsed.manualTunnelUrl || "").url
  };
}

function writeSetupPrefs(prefs) {
  ensureDataDir();
  fs.writeFileSync(SETUP_PREFS_FILE, JSON.stringify({
    manualTunnelUrl: prefs.manualTunnelUrl || "",
    updatedAt: new Date().toISOString()
  }, null, 2), { mode: 0o600 });
}

function setManualTunnelUrl(value) {
  var cleaned = cleanSetupTunnelUrl(value);
  var prefs;

  if (!cleaned.ok) {
    return cleaned;
  }

  prefs = readSetupPrefs();
  prefs.manualTunnelUrl = cleaned.url;
  writeSetupPrefs(prefs);

  return {
    ok: true,
    url: cleaned.url
  };
}

function cleanSetupTunnelUrl(value) {
  var text = String(value || "").trim();
  var parsed;
  var formatted;

  if (!text) {
    return {
      ok: true,
      url: ""
    };
  }

  if (text.length > 300) {
    return {
      ok: false,
      status: 400,
      error: "Use a shorter URL."
    };
  }

  if (/[\x00-\x20\x7f]/.test(text)) {
    return {
      ok: false,
      status: 400,
      error: "Use a single URL with no spaces."
    };
  }

  if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(text)) {
    text = "https://" + text;
  }

  try {
    parsed = new URL(text);
  } catch (err) {
    return {
      ok: false,
      status: 400,
      error: "Use a valid URL."
    };
  }

  if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
    return {
      ok: false,
      status: 400,
      error: "Use an http:// or https:// URL."
    };
  }

  if (!parsed.hostname || parsed.username || parsed.password) {
    return {
      ok: false,
      status: 400,
      error: "Use a shareable URL without a username or password."
    };
  }

  formatted = parsed.protocol + "//" + parsed.host + (parsed.pathname || "/") + parsed.search;
  return {
    ok: true,
    url: formatted
  };
}

function generatePin() {
  if (crypto.randomInt) {
    return String(crypto.randomInt(100000, 1000000));
  }
  return String(Math.floor(100000 + Math.random() * 900000));
}

function authPublicState(unlocked) {
  var config = authConfig();
  return {
    enabled: config.enabled,
    unlocked: !!unlocked || !config.enabled,
    source: config.enabled ? config.source : "disabled",
    custom: !!config.custom,
    demoMode: DEMO_MODE
  };
}

function requestPin(req) {
  var header = req.headers["x-codex-pet-pin"] || "";
  var authHeader = req.headers.authorization || "";

  if (!header && /^Bearer\s+/i.test(authHeader)) {
    header = authHeader.replace(/^Bearer\s+/i, "");
  }

  return String(header || "").trim();
}

function pinMatches(pin) {
  var config = authConfig();
  var actualHash;
  var inputHash;

  if (!config.enabled) {
    return true;
  }

  if (!pin) {
    return false;
  }

  actualHash = crypto.createHash("sha256").update(String(config.pin)).digest();
  inputHash = crypto.createHash("sha256").update(String(pin)).digest();
  return crypto.timingSafeEqual(actualHash, inputHash);
}

function requireApiAuth(req, res) {
  if (pinMatches(requestPin(req))) {
    return true;
  }

  sendJson(res, 401, {
    error: "Authentication required",
    authRequired: true,
    auth: authPublicState(false)
  });
  return false;
}

function isLocalRequest(req) {
  var address = req.socket && req.socket.remoteAddress ? String(req.socket.remoteAddress) : "";
  return address === "127.0.0.1" ||
    address === "::1" ||
    address === "::ffff:127.0.0.1";
}

function readStatus() {
  ensureDataDir();
  try {
    var raw = fs.readFileSync(STATUS_FILE, "utf8");
    var parsed = JSON.parse(raw);
    return normalizeStatus(parsed, false);
  } catch (err) {
    writeStatus(defaultStatus);
    return defaultStatus;
  }
}

function writeStatus(status) {
  ensureDataDir();
  fs.writeFileSync(STATUS_FILE, JSON.stringify(status, null, 2));
}

function readTasks() {
  ensureDataDir();
  try {
    var raw = fs.readFileSync(TASKS_FILE, "utf8");
    var parsed = JSON.parse(raw);
    var list = Array.isArray(parsed) ? parsed : parsed.tasks;
    if (!Array.isArray(list)) {
      list = [];
    }
    list = normalizeTaskList(list);
    if (!list.length) {
      list = [taskFromStatus(readStatusSafe(), "current")];
    }
    return sortTasks(list);
  } catch (err) {
    var seeded = [taskFromStatus(readStatusSafe(), "current")];
    writeTasks(seeded);
    return seeded;
  }
}

function readBoardTasks() {
  if (DEMO_MODE) {
    return readDemoTasks();
  }

  var recent = readCodexRecentTasks();
  if (recent.length) {
    return recent;
  }
  return readTasks();
}

function readDemoTasks() {
  var raw;
  var parsed;
  var list;

  try {
    raw = fs.readFileSync(DEMO_TASKS_FILE, "utf8");
    parsed = JSON.parse(raw);
    list = Array.isArray(parsed) ? parsed : parsed.tasks;
  } catch (err) {
    list = [];
  }

  if (!Array.isArray(list) || !list.length) {
    list = [{
      id: "demo-empty",
      state: "idle",
      title: "Demo task board",
      message: "Demo mode is running",
      detail: "Add sample tasks to examples/demo-tasks.json.",
      progress: 0,
      source: "demo",
      sourceLabel: "Demo",
      timeLabel: "now",
      snippets: [
        {
          role: "assistant",
          text: "Demo mode is active and does not read real Codex data."
        }
      ]
    }];
  }

  return sortTasks(normalizeTaskList(list));
}

function invalidateRecentCodexCache() {
  recentCodexCache.checkedAt = 0;
  recentCodexCache.tasks = [];
}

function rolloutFileInfo(rolloutPath) {
  var stat;

  if (!rolloutPath) {
    return null;
  }

  try {
    stat = fs.statSync(rolloutPath);
  } catch (err) {
    return null;
  }

  if (!stat.isFile()) {
    return null;
  }

  return {
    path: rolloutPath,
    size: stat.size,
    mtimeMs: stat.mtimeMs
  };
}

function readRolloutCache(cache, info) {
  var item = info && cache[info.path];

  if (item && item.size === info.size && item.mtimeMs === info.mtimeMs) {
    return item.value;
  }
  return null;
}

function writeRolloutCache(cache, info, value) {
  if (info) {
    cache[info.path] = {
      size: info.size,
      mtimeMs: info.mtimeMs,
      value: value
    };
  }
  return value;
}

function readBoardTasksAsync() {
  if (DEMO_MODE) {
    return Promise.resolve(readDemoTasks());
  }

  return waitForCodexThreadTitleRefresh().then(function () {
    readBoardTasks();
    return waitForMissingCodexThreadTitleReads().then(function () {
      return readBoardTasks();
    });
  });
}

function refreshCodexThreadTitleCacheIfNeeded(force) {
  var now = new Date().getTime();
  var params;

  if (!fs.existsSync(CODEX_BIN)) {
    codexThreadTitleCache.error = "Codex app was not found.";
    return Promise.resolve(codexThreadTitleCache);
  }

  if (!force && now - codexThreadTitleCache.checkedAt < CODEX_THREAD_TITLE_TTL_MS) {
    return Promise.resolve(codexThreadTitleCache);
  }

  if (codexThreadTitleCache.loading) {
    return codexThreadTitleCache.loading;
  }

  codexThreadTitleCache.checkedAt = now;
  params = {
    limit: CODEX_THREAD_TITLE_LIMIT,
    sortKey: "updated_at",
    sortDirection: "desc",
    archived: false
  };

  codexThreadTitleCache.loading = ensureCodexRpcClient().then(function (client) {
    return client.request("thread/list", params, CODEX_THREAD_TITLE_TIMEOUT_MS);
  }).then(function (result) {
    updateCodexThreadTitleCacheFromList(result && result.data);
    codexThreadTitleCache.error = "";
    return codexThreadTitleCache;
  }).catch(function (err) {
    codexThreadTitleCache.error = err && err.message ? err.message : String(err || "Codex title refresh failed.");
    return codexThreadTitleCache;
  }).then(function (cache) {
    codexThreadTitleCache.loading = null;
    return cache;
  });

  return codexThreadTitleCache.loading;
}

function waitForCodexThreadTitleRefresh() {
  var refresh = refreshCodexThreadTitleCacheIfNeeded(false);

  return new Promise(function (resolve) {
    var settled = false;
    var timer = setTimeout(function () {
      if (!settled) {
        settled = true;
        resolve(codexThreadTitleCache);
      }
    }, Math.max(100, CODEX_THREAD_TITLE_WAIT_MS));

    refresh.then(function (cache) {
      if (!settled) {
        settled = true;
        clearTimeout(timer);
        resolve(cache);
      }
    }).catch(function () {
      if (!settled) {
        settled = true;
        clearTimeout(timer);
        resolve(codexThreadTitleCache);
      }
    });
  });
}

function waitForMissingCodexThreadTitleReads() {
  var refresh = codexThreadTitleCache.missingLoading;

  if (!refresh) {
    return Promise.resolve(codexThreadTitleCache);
  }

  return new Promise(function (resolve) {
    var settled = false;
    var timer = setTimeout(function () {
      if (!settled) {
        settled = true;
        resolve(codexThreadTitleCache);
      }
    }, Math.max(100, Math.min(800, CODEX_THREAD_TITLE_WAIT_MS)));

    refresh.then(function () {
      if (!settled) {
        settled = true;
        clearTimeout(timer);
        resolve(codexThreadTitleCache);
      }
    }).catch(function () {
      if (!settled) {
        settled = true;
        clearTimeout(timer);
        resolve(codexThreadTitleCache);
      }
    });
  });
}

function updateCodexThreadTitleCacheFromList(list) {
  var next = {};
  var changed = false;
  var current = codexThreadTitleCache.titles || {};
  var rows = Array.isArray(list) ? list : [];
  var i;
  var entry;
  var keys;

  keys = Object.keys(current);
  for (i = 0; i < keys.length; i += 1) {
    next[keys[i]] = current[keys[i]];
  }

  for (i = 0; i < rows.length; i += 1) {
    entry = codexThreadTitleEntry(rows[i]);
    if (entry) {
      if (!current[entry.id] || current[entry.id].title !== entry.title) {
        changed = true;
      }
      next[entry.id] = entry;
    }
  }

  codexThreadTitleCache.titles = next;
  codexThreadTitleCache.checkedAt = new Date().getTime();
  if (changed) {
    invalidateRecentCodexCache();
  }
}

function refreshMissingCodexThreadTitles(rows) {
  var ids = [];
  var seen = {};
  var batch;
  var i;
  var row;
  var threadId;

  if (!Array.isArray(rows) || !rows.length || !fs.existsSync(CODEX_BIN)) {
    return Promise.resolve(codexThreadTitleCache);
  }

  for (i = 0; i < rows.length && ids.length < RECENT_LIMIT; i += 1) {
    row = rows[i] || {};
    threadId = row.id ? String(row.id) : "";
    if (!threadId || seen[threadId] || skipCodexThread(row) || cachedCodexThreadTitle(threadId) || codexThreadTitleCache.reading[threadId]) {
      continue;
    }
    seen[threadId] = true;
    ids.push(threadId);
    codexThreadTitleCache.reading[threadId] = true;
  }

  if (!ids.length) {
    return Promise.resolve(codexThreadTitleCache);
  }

  batch = ensureCodexRpcClient().then(function (client) {
    return Promise.all(ids.map(function (id) {
      var read = client.request("thread/read", {
        threadId: id,
        includeTurns: false
      }, CODEX_THREAD_TITLE_TIMEOUT_MS).then(function (result) {
        updateCodexThreadTitleCacheEntry(result && result.thread);
      }).catch(function () {
      }).then(function () {
        delete codexThreadTitleCache.reading[id];
      });
      codexThreadTitleCache.reading[id] = read;
      return read;
    }));
  }).catch(function () {
    ids.forEach(function (id) {
      delete codexThreadTitleCache.reading[id];
    });
  }).then(function () {
    if (codexThreadTitleCache.missingLoading === batch) {
      codexThreadTitleCache.missingLoading = null;
    }
    return codexThreadTitleCache;
  });

  codexThreadTitleCache.missingLoading = batch;
  return batch;
}

function updateCodexThreadTitleCacheEntry(thread) {
  var entry = codexThreadTitleEntry(thread);
  var current;

  if (!entry) {
    return;
  }

  current = codexThreadTitleCache.titles[entry.id];
  if (!current || current.title !== entry.title) {
    codexThreadTitleCache.titles[entry.id] = entry;
    invalidateRecentCodexCache();
  }
}

function codexThreadTitleEntry(thread) {
  var id = thread && thread.id ? String(thread.id) : "";
  var name;
  var preview;
  var raw;
  var source;

  if (!id) {
    return null;
  }

  name = typeof thread.name === "string" ? thread.name.trim() : "";
  preview = typeof thread.preview === "string" ? thread.preview.trim() : "";
  raw = name || preview || id;
  source = name ? "name" : (preview ? "preview" : "id");

  return {
    id: id,
    title: cleanCodexDisplayTitle(raw, id),
    source: source
  };
}

function cleanCodexDisplayTitle(value, fallback) {
  var text = cleanText(value, fallback || "Codex task", TASK_TITLE_LIMIT);
  text = text.replace(/\s+/g, " ").trim();
  return text || fallback || "Codex task";
}

function cachedCodexThreadTitle(threadId) {
  var entry = codexThreadTitleCache.titles && codexThreadTitleCache.titles[String(threadId || "")];
  return entry && entry.title ? entry.title : "";
}

function titleForCodexThread(row) {
  return cachedCodexThreadTitle(row && row.id) || cleanCodexTitle(row.title || row.first_user_message || "Codex task");
}

function updateCodexThreadTitleFromNotification(params) {
  var threadId = params && params.threadId ? String(params.threadId) : "";
  var name = params && typeof params.threadName === "string" ? params.threadName.trim() : "";

  if (!threadId) {
    return;
  }

  if (name) {
    codexThreadTitleCache.titles[threadId] = {
      id: threadId,
      title: cleanCodexDisplayTitle(name, threadId),
      source: "name"
    };
  } else {
    delete codexThreadTitleCache.titles[threadId];
    codexThreadTitleCache.checkedAt = 0;
    refreshCodexThreadTitleCacheIfNeeded(true);
  }
  invalidateRecentCodexCache();
}

function readCodexRecentTasks() {
  var now = new Date().getTime();
  var query;
  var raw;
  var rows;
  var tasks;
  var i;
  var task;

  refreshCodexThreadTitleCacheIfNeeded(false);

  if (now - recentCodexCache.checkedAt < 800) {
    return recentCodexCache.tasks;
  }

  recentCodexCache.checkedAt = now;

  if (!fs.existsSync(CODEX_STATE_DB)) {
    recentCodexCache.tasks = [];
    return [];
  }

  query = [
    "SELECT id,title,rollout_path,substr(preview,1,2500) AS preview,substr(first_user_message,1,1200) AS first_user_message,source,thread_source,archived,has_user_event,",
    "updated_at,updated_at_ms,created_at,created_at_ms,tokens_used,cwd,agent_nickname,agent_role ",
    "FROM threads ",
    "WHERE archived = 0 ",
    "ORDER BY COALESCE(updated_at_ms, updated_at * 1000) DESC ",
    "LIMIT 40;"
  ].join("");

  try {
    raw = childProcess.execFileSync("sqlite3", ["-json", CODEX_STATE_DB, query], {
      encoding: "utf8",
      timeout: 2000
    });
    rows = JSON.parse(raw || "[]");
  } catch (err) {
    recentCodexCache.tasks = [];
    return [];
  }

  refreshMissingCodexThreadTitles(rows);

  tasks = [];
  var activeIds = readActiveThreadIds();
  for (i = 0; i < rows.length && tasks.length < RECENT_LIMIT; i += 1) {
    if (skipCodexThread(rows[i])) {
      continue;
    }
    task = codexThreadToTask(rows[i], tasks.length, activeIds);
    if (task) {
      tasks.push(task);
    }
  }

  recentCodexCache.tasks = tasks;
  return tasks;
}

function readActiveThreadIds() {
  var ids = {};
  var raw;
  var rows;
  var now = new Date().getTime();
  var cutoff = Math.floor(Date.now() / 1000) - ACTIVE_WINDOW_SECONDS;
  var query = [
    "SELECT thread_id, MAX(ts) AS last_ts FROM logs ",
    "WHERE thread_id IS NOT NULL AND thread_id != '' ",
    "AND ts >= " + cutoff + " ",
    "AND feedback_log_body LIKE '%:turn{%' ",
    "GROUP BY thread_id;"
  ].join("");
  var i;

  if (now - activeThreadIdsCache.checkedAt < 3000) {
    return activeThreadIdsCache.ids;
  }

  if (!fs.existsSync(CODEX_LOGS_DB)) {
    activeThreadIdsCache.checkedAt = now;
    activeThreadIdsCache.ids = ids;
    return ids;
  }

  try {
    raw = childProcess.execFileSync("sqlite3", ["-json", CODEX_LOGS_DB, query], {
      encoding: "utf8",
      timeout: 1500
    });
    rows = JSON.parse(raw || "[]");
  } catch (err) {
    activeThreadIdsCache.checkedAt = now;
    activeThreadIdsCache.ids = ids;
    return ids;
  }

  for (i = 0; i < rows.length; i += 1) {
    if (rows[i].thread_id) {
      ids[rows[i].thread_id] = Number(rows[i].last_ts) || 0;
    }
  }

  activeThreadIdsCache.checkedAt = now;
  activeThreadIdsCache.ids = ids;
  return ids;
}

function skipCodexThread(row) {
  var title = String(row && row.title || "");
  var first = String(row && row.first_user_message || "");

  if (!row || !row.id) {
    return true;
  }
  if (title.indexOf("The following is the Codex agent history") === 0) {
    return true;
  }
  if (first.indexOf("The following is the Codex agent history") === 0) {
    return true;
  }
  return false;
}

function codexThreadToTask(row, index, activeIds) {
  var updatedMs = Number(row.updated_at_ms) || Number(row.updated_at) * 1000 || new Date().getTime();
  var createdMs = Number(row.created_at_ms) || Number(row.created_at) * 1000 || updatedMs;
  var ageMs = Math.max(0, new Date().getTime() - updatedMs);
  var activity = rolloutActivity(row.rollout_path);
  var state = stateFromThreadActivity(row, updatedMs, activeIds, activity);
  var conversation = recentMessagesForThread(row.rollout_path, row.preview || row.first_user_message || "");
  var snippets = conversation.snippets;
  var activeTurnId = activity.lastStartAt > activity.lastCompleteAt ? activity.lastStartTurnId : "";

  return normalizeTask({
    id: row.id,
    state: state,
    title: titleForCodexThread(row),
    message: snippets.length ? snippets[0].text : codexMessage(row, ageMs, state),
    detail: codexDetail(row, ageMs),
    progress: codexProgress(state),
    updatedAt: new Date(updatedMs).toISOString(),
    startedAt: new Date(createdMs).toISOString(),
    source: "codex",
    sourceLabel: "Codex",
    projectLabel: projectLabelFromCwd(row.cwd),
    timeLabel: ageLabel(ageMs),
    threadId: row.id,
    activeTurnId: activeTurnId,
    snippets: snippets,
    detailSnippets: conversation.detailSnippets
  }, {}, false);
}

function projectLabelFromCwd(cwd) {
  var folder;

  if (!cwd) {
    return "";
  }

  cwd = String(cwd);
  if (cwd === os.homedir()) {
    return "";
  }

  folder = path.basename(cwd);
  if (!folder || folder === "." || folder === path.basename(os.homedir())) {
    return "";
  }
  return folder;
}

function stateFromThreadActivity(row, updatedMs, activeIds, activity) {
  var activeLogTs = activeIds && activeIds[row.id] ? Number(activeIds[row.id]) : 0;
  var now = new Date().getTime();
  var logIsFresh = activeLogTs && activeLogTs * 1000 >= now - ACTIVE_WINDOW_SECONDS * 1000;
  var updatedIsFresh = updatedMs >= now - ACTIVE_WINDOW_SECONDS * 1000;
  var openTurnAge;

  activity = activity || rolloutActivity(row.rollout_path);

  if (activity.lastCompleteAt && activity.lastCompleteAt >= activity.lastStartAt) {
    return "done";
  }

  if (activity.lastStartAt && activity.lastStartAt > activity.lastCompleteAt) {
    openTurnAge = now - activity.lastStartAt;
    if (logIsFresh || updatedIsFresh || openTurnAge <= ACTIVE_WINDOW_SECONDS * 1000) {
      return "working";
    }
    if (openTurnAge <= STALE_OPEN_TURN_SECONDS * 1000) {
      return "waiting";
    }
    return "done";
  }

  if (logIsFresh && updatedIsFresh) {
    return "working";
  }

  return "done";
}

function rolloutActivity(rolloutPath) {
  var activity = {
    lastStartAt: 0,
    lastCompleteAt: 0,
    lastStartTurnId: "",
    lastCompleteTurnId: ""
  };
  var info = rolloutFileInfo(rolloutPath);
  var cached = readRolloutCache(rolloutActivityCache, info);
  var lines;
  var i;
  var entry;
  var payload;
  var time;

  if (cached) {
    return cached;
  }

  if (!info) {
    return activity;
  }

  try {
    lines = tailLines(info.path, 900, 4 * 1024 * 1024);
  } catch (err) {
    return activity;
  }

  for (i = 0; i < lines.length; i += 1) {
    entry = parseJsonLine(lines[i]);
    if (!entry || entry.type !== "event_msg" || !entry.payload) {
      continue;
    }

    payload = entry.payload;
    if (payload.type !== "task_started" &&
        payload.type !== "task_complete" &&
        payload.type !== "turn_aborted") {
      continue;
    }

    time = Date.parse(entry.timestamp || "");
    if (!time) {
      continue;
    }

    if (payload.type === "task_started") {
      activity.lastStartAt = time;
      activity.lastStartTurnId = payload.turn_id || "";
    } else {
      activity.lastCompleteAt = time;
      activity.lastCompleteTurnId = payload.turn_id || "";
    }
  }

  return writeRolloutCache(rolloutActivityCache, info, activity);
}

function codexProgress(state) {
  if (state === "working") {
    return 65;
  }
  if (state === "waiting") {
    return 90;
  }
  return 100;
}

function cleanCodexTitle(value) {
  var text = cleanText(value, "Codex task", TASK_TITLE_LIMIT);
  text = text.replace(/\s+/g, " ").trim();
  return text || "Codex task";
}

function codexMessage(row, ageMs, state) {
  var line = firstUsefulLine(row.preview || row.first_user_message || "");
  if (line) {
    return cleanText(line, "", 72);
  }
  if (state === "working") {
    return "Recently active";
  }
  if (state === "waiting") {
    return "Recent task";
  }
  return "Completed recently";
}

function recentMessagesForThread(rolloutPath, fallbackText) {
  var messages = [];
  var fallbackMessages;
  var selected;
  var info = rolloutFileInfo(rolloutPath);
  var cached = readRolloutCache(rolloutMessagesCache, info);
  var lines;
  var i;
  var entry;
  var msg;
  var limit = Math.max(1, SNIPPET_LIMIT || 15);

  if (cached) {
    messages = cached.slice();
  } else if (info) {
    try {
      lines = tailLines(info.path, 5000, 16 * 1024 * 1024);
      for (i = 0; i < lines.length; i += 1) {
        entry = parseJsonLine(lines[i]);
        msg = messageFromRolloutEntry(entry);
        if (msg && !isDuplicateMessage(messages, msg)) {
          messages.push(msg);
        }
      }
    } catch (err) {
      messages = [];
    }
    writeRolloutCache(rolloutMessagesCache, info, messages.slice());
  }

  if (!messages.length && fallbackText) {
    messages = fallbackSnippetMessages(fallbackText);
  } else if (messages.length <= 1 && messages.length < limit && fallbackText) {
    fallbackMessages = fallbackSnippetMessages(fallbackText);
    if (fallbackMessages.length > messages.length) {
      messages = fallbackMessages;
    }
  }

  selected = selectSnippetMessages(messages);

  return {
    snippets: selected.map(function (item) {
      return {
        role: item.role,
        text: cleanText(item.text, "", SNIPPET_TEXT_LIMIT)
      };
    }),
    detailSnippets: selected.map(function (item) {
      return {
        role: item.role,
        text: cleanText(item.text, "", DETAIL_MESSAGE_TEXT_LIMIT)
      };
    })
  };
}

function fallbackSnippetMessages(text) {
  var limit = Math.max(1, SNIPPET_LIMIT || 15);
  var lines = String(text || "").split(/\n+/);
  var out = [];
  var seen = {};
  var i;
  var item;

  for (i = 0; i < lines.length; i += 1) {
    item = fallbackSnippetLine(lines[i]);
    if (!item || seen[item.text]) {
      continue;
    }
    seen[item.text] = true;
    out.push(item);
  }

  return out.slice(-limit);
}

function fallbackSnippetLine(line) {
  var role = "user";
  var text = String(line || "").replace(/\s+/g, " ").trim();
  var match;

  if (!text || text === "(No content)") {
    return null;
  }
  if (/^\d{1,2}:\d{2}\s?(AM|PM)?$/i.test(text)) {
    return null;
  }
  if (/^(Worked for|User attachment|Invalid image|Reconnecting)/i.test(text)) {
    return null;
  }

  match = text.match(/^(?:\[\d+\]\s*)?(user|assistant|ai|codex)\s*:\s*(.+)$/i);
  if (match) {
    role = /assistant|ai|codex/i.test(match[1]) ? "assistant" : "user";
    text = match[2];
  }

  text = cleanText(text, "", DETAIL_MESSAGE_TEXT_LIMIT);
  return text ? { role: role, text: text } : null;
}

function selectSnippetMessages(messages) {
  var limit = Math.max(1, SNIPPET_LIMIT || 15);
  var selected = messages.slice(-limit);
  var hasUser = false;
  var i;

  for (i = 0; i < selected.length; i += 1) {
    if (selected[i].role === "user") {
      hasUser = true;
      break;
    }
  }

  if (!hasUser) {
    for (i = messages.length - 1; i >= 0; i -= 1) {
      if (messages[i].role === "user") {
        if (selected.length >= limit) {
          selected[0] = messages[i];
        } else {
          selected.unshift(messages[i]);
        }
        break;
      }
    }
  }

  return selected;
}

function tailLines(filePath, maxLines, maxBuffer) {
  var fd = null;
  var stat;
  var bytesToRead;
  var start;
  var buffer;
  var raw;
  var lines;

  fd = fs.openSync(filePath, "r");
  try {
    stat = fs.fstatSync(fd);
    bytesToRead = Math.min(stat.size, maxBuffer || 1024 * 1024);
    start = Math.max(0, stat.size - bytesToRead);
    buffer = Buffer.alloc(bytesToRead);
    fs.readSync(fd, buffer, 0, bytesToRead, start);
  } finally {
    fs.closeSync(fd);
  }

  raw = buffer.toString("utf8");
  lines = raw.split(/\n/);
  if (start > 0) {
    lines.shift();
  }
  if (lines.length > maxLines) {
    lines = lines.slice(-maxLines);
  }
  return lines;
}

function parseJsonLine(line) {
  if (!line) {
    return null;
  }
  try {
    return JSON.parse(line);
  } catch (err) {
    return null;
  }
}

function messageFromRolloutEntry(entry) {
  var payload;
  var content;
  var text;

  if (!entry || !entry.payload) {
    return null;
  }

  payload = entry.payload;

  if (entry.type === "event_msg" && payload.type === "user_message") {
    text = cleanMessageText(payload.message || "", DETAIL_MESSAGE_TEXT_LIMIT);
    return text ? { role: "user", text: text } : null;
  }

  if (entry.type === "response_item" && payload.type === "message" && payload.role === "assistant") {
    content = payload.content || [];
    text = textFromContent(content);
    text = cleanMessageText(text, DETAIL_MESSAGE_TEXT_LIMIT);
    return text ? { role: "assistant", text: text } : null;
  }

  return null;
}

function textFromContent(content) {
  var out = [];
  var i;
  var item;

  if (!Array.isArray(content)) {
    return "";
  }

  for (i = 0; i < content.length; i += 1) {
    item = content[i];
    if (item && typeof item.text === "string") {
      out.push(item.text);
    } else if (item && typeof item.output_text === "string") {
      out.push(item.output_text);
    }
  }

  return out.join(" ");
}

function cleanMessageText(text, limit) {
  var maxLength = typeof limit === "number" ? limit : DETAIL_MESSAGE_TEXT_LIMIT;
  text = String(text || "");
  text = text.replace(/# In app browser:[\s\S]*?## My request for Codex:/g, "");
  text = text.replace(/<environment_context>[\s\S]*?<\/environment_context>/g, "");
  text = text.replace(/\s+/g, " ").trim();
  if (!text || text === "(No content)") {
    return "";
  }
  if (maxLength > 0 && text.length > maxLength) {
    text = text.slice(0, maxLength - 1) + "...";
  }
  return text;
}

function isDuplicateMessage(messages, msg) {
  var last = messages[messages.length - 1];
  return !!last && last.role === msg.role && last.text === msg.text;
}

function codexDetail(row, ageMs) {
  var cwd = row.cwd ? path.basename(String(row.cwd)) : "";
  var bits = ["updated " + ageLabel(ageMs)];
  if (cwd) {
    bits.push(cwd);
  }
  return bits.join(" · ");
}

function firstUsefulLine(text) {
  var lines = String(text || "").split(/\n+/);
  var i;
  var line;

  for (i = 0; i < lines.length; i += 1) {
    line = lines[i].replace(/\s+/g, " ").trim();
    if (!line) {
      continue;
    }
    if (/^\d{1,2}:\d{2}\s?(AM|PM)?$/i.test(line)) {
      continue;
    }
    if (line.indexOf("Worked for ") === 0) {
      continue;
    }
    return line;
  }

  return "";
}

function ageLabel(ageMs) {
  var minutes = Math.max(0, Math.floor(ageMs / 60000));
  var hours;
  var days;

  if (minutes < 1) {
    return "now";
  }
  if (minutes < 60) {
    return minutes + "m";
  }
  hours = Math.floor(minutes / 60);
  if (hours < 24) {
    return hours + "h";
  }
  days = Math.floor(hours / 24);
  return days + "d";
}

function writeTasks(tasks) {
  ensureDataDir();
  fs.writeFileSync(TASKS_FILE, JSON.stringify(sortTasks(tasks), null, 2));
}

function readInstructions() {
  ensureDataDir();
  try {
    var raw = fs.readFileSync(INSTRUCTIONS_FILE, "utf8");
    var parsed = JSON.parse(raw);
    var list = Array.isArray(parsed) ? parsed : parsed.instructions;
    if (Array.isArray(list)) {
      return normalizeInstructions(list);
    }
  } catch (err) {
  }
  return [];
}

function writeInstructions(instructions) {
  ensureDataDir();
  fs.writeFileSync(INSTRUCTIONS_FILE, JSON.stringify(instructions.slice(-200), null, 2));
}

function normalizeInstructions(list) {
  var out = [];
  var i;
  for (i = 0; i < list.length; i += 1) {
    out.push(normalizeInstruction(list[i]));
  }
  return out;
}

function normalizeInstruction(input) {
  var now = new Date().toISOString();
  input = input || {};
  return {
    id: cleanId(input.id || "ins-" + new Date().getTime() + "-" + Math.floor(Math.random() * 10000), "instruction"),
    taskId: cleanId(input.taskId || input.id || "current", "current"),
    taskTitle: cleanText(input.taskTitle, "", 64),
    text: cleanInstructionText(input.text || input.instruction || ""),
    status: cleanInstructionStatus(input.status || "queued"),
    createdAt: input.createdAt || now,
    updatedAt: input.updatedAt || input.createdAt || now,
    delivery: cleanText(input.delivery, "", 24),
    deliveryMethod: cleanText(input.deliveryMethod, "", 48),
    deliveryError: cleanText(input.deliveryError, "", 180),
    turnId: cleanText(input.turnId, "", 48)
  };
}

function cleanInstructionStatus(value) {
  value = String(value || "queued").toLowerCase();
  if (value === "queued" || value === "sent" || value === "done" || value === "failed") {
    return value;
  }
  return "queued";
}

function cleanInstructionText(value) {
  var text = String(value || "");
  text = text.replace(/\r\n/g, "\n").replace(/\r/g, "\n").replace(/\t/g, "  ");
  text = text.replace(/\n\n\n+/g, "\n\n").trim();
  if (text.length > 800) {
    text = text.slice(0, 799) + "...";
  }
  return text;
}

function pendingInstructionCounts(instructions) {
  var counts = {};
  var i;
  var item;
  for (i = 0; i < instructions.length; i += 1) {
    item = instructions[i];
    if (item.status === "queued") {
      counts[item.taskId] = (counts[item.taskId] || 0) + 1;
    }
  }
  return counts;
}

function markStartupQueuedInstructionsFailed() {
  var instructions = readInstructions();
  var now = new Date().getTime();
  var changed = false;
  var i;
  var createdAt;

  for (i = 0; i < instructions.length; i += 1) {
    if (instructions[i].status === "queued") {
      createdAt = Date.parse(instructions[i].createdAt || "");
      if (createdAt && now - createdAt <= STARTUP_QUEUED_RESUME_WINDOW_MS) {
        instructions[i].delivery = "queued";
        instructions[i].deliveryMethod = instructions[i].deliveryMethod || "startup-resume";
        instructions[i].deliveryError = "";
      } else {
        instructions[i].status = "failed";
        instructions[i].delivery = "failed";
        instructions[i].deliveryError = "This queued instruction expired while ScreenPet was not running. Send it again to deliver it to Codex.";
      }
      instructions[i].updatedAt = startupAt;
      changed = true;
    }
  }

  if (changed) {
    writeInstructions(instructions);
  }
}

function resumeStartupQueuedInstructions() {
  var instructions = readInstructions();
  var i;

  for (i = 0; i < instructions.length; i += 1) {
    if (instructions[i].status === "queued") {
      deliverInstructionInBackground(instructions[i]);
    }
  }
}

function decorateTasks(tasks, instructions) {
  var counts = pendingInstructionCounts(instructions);
  var out = [];
  var i;
  var task;
  for (i = 0; i < tasks.length; i += 1) {
    task = copyTask(tasks[i]);
    task.pendingInstructions = counts[task.id] || 0;
    if (task.pendingInstructions) {
      task.state = "waiting";
      if (task.progress > 90) {
        task.progress = 90;
      }
    }
    out.push(task);
  }
  return out;
}

function copyTask(task) {
  var next = {};
  Object.keys(task || {}).forEach(function (key) {
    next[key] = task[key];
  });
  return next;
}

function addInstruction(input) {
  var tasks = readBoardTasks();
  var taskId = cleanId(input.taskId || input.id || "current", "current");
  var task = findTask(tasks, taskId);
  var instructions = readInstructions();
  var item = normalizeInstruction({
    taskId: taskId,
    taskTitle: task ? task.title : "",
    text: input.text || input.instruction,
    status: "queued"
  });

  if (!item.text) {
    return null;
  }

  instructions.push(item);
  writeInstructions(instructions);
  return item;
}

function updateInstructionDelivery(id, patch) {
  var instructions = readInstructions();
  var now = new Date().toISOString();
  var i;
  var item;

  id = cleanId(id, "");
  if (!id) {
    return null;
  }

  for (i = 0; i < instructions.length; i += 1) {
    if (instructions[i].id === id) {
      item = instructions[i];
      if (patch.status) {
        item.status = cleanInstructionStatus(patch.status);
      }
      if (typeof patch.delivery !== "undefined") {
        item.delivery = cleanText(patch.delivery, "", 24);
      }
      if (typeof patch.deliveryMethod !== "undefined") {
        item.deliveryMethod = cleanText(patch.deliveryMethod, "", 48);
      }
      if (typeof patch.deliveryError !== "undefined") {
        item.deliveryError = cleanText(patch.deliveryError, "", 180);
      }
      if (typeof patch.turnId !== "undefined") {
        item.turnId = cleanText(patch.turnId, "", 48);
      }
      item.updatedAt = now;
      writeInstructions(instructions);
      return item;
    }
  }

  return null;
}

function threadIdForInstruction(item) {
  var tasks = readBoardTasks();
  var task = findTask(tasks, item.taskId);
  return task && task.threadId ? task.threadId : item.taskId;
}

function findTask(tasks, id) {
  var i;
  for (i = 0; i < tasks.length; i += 1) {
    if (tasks[i].id === id) {
      return tasks[i];
    }
  }
  return null;
}

function normalizeTaskList(list) {
  var out = [];
  var seen = {};
  var i;
  var task;

  for (i = 0; i < list.length; i += 1) {
    task = normalizeTask(list[i], {}, false);
    if (!seen[task.id]) {
      seen[task.id] = true;
      out.push(task);
    }
  }

  return out;
}

function taskFromStatus(status, id) {
  return normalizeTask({
    id: id,
    state: status.state,
    title: status.task || status.title,
    message: status.message,
    detail: status.detail,
    progress: status.progress,
    updatedAt: status.updatedAt,
    startedAt: status.startedAt
  }, {}, false);
}

function normalizeTask(input, previous, updateClock) {
  var now = new Date().toISOString();
  var task = {};
  var state;

  input = input || {};
  previous = previous || {};
  state = String(input.state || previous.state || "idle").toLowerCase();

  if (!states[state]) {
    state = "idle";
  }

  task.id = cleanId(input.id || input.taskId || previous.id || "current", "current");
  task.state = state;
  task.title = cleanText(input.title || input.task, previous.title || "Untitled task", TASK_TITLE_LIMIT);
  task.message = cleanText(input.message, previous.message || "", 72);
  task.detail = cleanText(input.detail, previous.detail || "", 120);
  task.progress = clampProgress(input.progress, previous.progress || 0);
  task.updatedAt = updateClock ? now : input.updatedAt || previous.updatedAt || now;
  task.startedAt = input.startedAt || previous.startedAt || task.updatedAt;
  task.source = cleanText(input.source, previous.source || "local", 20);
  task.sourceLabel = cleanText(input.sourceLabel, previous.sourceLabel || task.source, 20);
  task.projectLabel = cleanText(input.projectLabel, previous.projectLabel || "", 48);
  task.timeLabel = cleanText(input.timeLabel, previous.timeLabel || "", 12);
  task.threadId = cleanText(input.threadId, previous.threadId || "", 48);
  task.activeTurnId = cleanText(input.activeTurnId, previous.activeTurnId || "", 48);
  task.snippets = normalizeSnippets(input.snippets || previous.snippets || [], SNIPPET_TEXT_LIMIT);
  task.detailSnippets = normalizeSnippets(input.detailSnippets || previous.detailSnippets || task.snippets || [], DETAIL_MESSAGE_TEXT_LIMIT);

  if (updateClock && state !== previous.state) {
    task.startedAt = task.updatedAt;
  }

  if (state === "done" && typeof input.progress === "undefined") {
    task.progress = 100;
  }

  if (state === "idle" && typeof input.progress === "undefined") {
    task.progress = 0;
  }

  return task;
}

function normalizeSnippets(snippets, textLimit) {
  var out = [];
  var i;
  var item;
  var limit = Math.max(1, Number(textLimit) || SNIPPET_TEXT_LIMIT);

  if (!Array.isArray(snippets)) {
    return out;
  }

  for (i = 0; i < snippets.length && out.length < Math.max(1, SNIPPET_LIMIT || 15); i += 1) {
    item = snippets[i] || {};
    out.push({
      role: item.role === "assistant" ? "assistant" : "user",
      text: cleanText(item.text, "", limit)
    });
  }

  return out;
}

function cleanId(value, fallback) {
  var text = String(value || fallback || "current").toLowerCase();
  text = text.replace(/[^a-z0-9._-]+/g, "-").replace(/^-+|-+$/g, "");
  if (!text) {
    text = fallback || "current";
  }
  if (text.length > 40) {
    text = text.slice(0, 40);
  }
  return text;
}

function sortTasks(tasks) {
  return tasks.slice(0).sort(function (a, b) {
    var ap = taskPriority(a);
    var bp = taskPriority(b);
    var at;
    var bt;

    if (ap !== bp) {
      return ap - bp;
    }

    at = Date.parse(a.updatedAt || "") || 0;
    bt = Date.parse(b.updatedAt || "") || 0;
    return bt - at;
  });
}

function taskPriority(task) {
  var priorities = {
    error: 0,
    working: 1,
    thinking: 2,
    waiting: 3,
    done: 8,
    idle: 9,
    offline: 10
  };
  return typeof priorities[task.state] === "number" ? priorities[task.state] : 9;
}

function activeTasks(tasks) {
  var out = [];
  var i;
  for (i = 0; i < tasks.length; i += 1) {
    if (tasks[i].state !== "done" && tasks[i].state !== "idle" && tasks[i].state !== "offline") {
      out.push(tasks[i]);
    }
  }
  return out;
}

function statusFromTasks(tasks) {
  var sorted = sortTasks(tasks);
  var active = activeTasks(sorted);
  var source = active[0] || sorted[0];
  var progress = 0;
  var i;

  if (!source) {
    return defaultStatus;
  }

  if (active.length) {
    for (i = 0; i < active.length; i += 1) {
      progress += Number(active[i].progress) || 0;
    }
    progress = Math.round(progress / active.length);
  } else {
    progress = source.progress;
  }

  return {
    state: source.state,
    title: active.length ? active.length + " running" : "Blinky Codex ScreenPet",
    task: source.title,
    message: source.message || (active.length ? "Tasks are running" : "No active task"),
    detail: active.length ? active.length + " active task" + (active.length === 1 ? "" : "s") : source.detail,
    progress: progress,
    updatedAt: source.updatedAt,
    startedAt: source.startedAt
  };
}

function taskBoard(req) {
  var tasks = readBoardTasks();
  var instructions = readInstructions();
  var decorated = decorateTasks(tasks, instructions);
  var active = activeTasks(decorated);

  return {
    status: statusFromTasks(decorated),
    connection: connectionInfo(req),
    permissions: boardPermissions(),
    activeCount: active.length,
    totalCount: tasks.length,
    pendingInstructionCount: activeInstructionCount(instructions),
    tasks: decorated,
    updatedAt: new Date().toISOString()
  };
}

function taskBoardAsync(req) {
  if (DEMO_MODE) {
    return Promise.resolve(taskBoard(req));
  }

  return readBoardTasksAsync().then(function (tasks) {
    var instructions = readInstructions();
    var decorated = decorateTasks(tasks, instructions);
    var active = activeTasks(decorated);

    return {
      status: statusFromTasks(decorated),
      connection: connectionInfo(req),
      permissions: boardPermissions(),
      activeCount: active.length,
      totalCount: tasks.length,
      pendingInstructionCount: activeInstructionCount(instructions),
      tasks: decorated,
      updatedAt: new Date().toISOString()
    };
  });
}

function connectionInfo(req) {
  var hostHeader = req && req.headers && req.headers.host ? String(req.headers.host) : "";
  var address = hostAddressFromHeader(hostHeader) || firstLocalAddress() || "127.0.0.1";
  var port = hostPortFromHeader(hostHeader) || String(PORT);

  return {
    deviceName: displayDeviceName(process.env.PET_DEVICE_NAME || defaultDeviceName()),
    address: address,
    host: address,
    port: port,
    url: "http://" + urlHost(address) + (port ? ":" + port : "") + "/",
    networkLabel: networkLabel(address),
    updatedAt: new Date().toISOString()
  };
}

function boardPermissions() {
  return {
    remoteControl: remoteControlPermissionStatus()
  };
}

function defaultDeviceName() {
  var name = "";

  if (deviceNameCache) {
    return deviceNameCache;
  }

  if (process.platform === "darwin") {
    try {
      name = childProcess.execFileSync("scutil", ["--get", "ComputerName"], {
        encoding: "utf8",
        timeout: 800
      });
    } catch (err) {
      name = "";
    }
  }

  deviceNameCache = String(name || os.hostname() || "This Mac").trim() || "This Mac";
  return deviceNameCache;
}

function displayDeviceName(value) {
  var name = String(value || "This Mac").trim();

  if (!name) {
    return "This Mac";
  }

  name = name.replace(/\.local$/i, "");
  name = name.replace(/-/g, " ");
  name = name.replace(/\s+/g, " ").trim();

  if (name.length > 34) {
    name = name.slice(0, 33) + "...";
  }

  return name || "This Mac";
}

function hostAddressFromHeader(value) {
  var host = String(value || "").trim();
  var end;

  if (!host) {
    return "";
  }

  if (host.charAt(0) === "[") {
    end = host.indexOf("]");
    return end > 0 ? host.slice(1, end) : "";
  }

  if ((host.match(/:/g) || []).length === 1) {
    return host.split(":")[0];
  }

  return host;
}

function hostPortFromHeader(value) {
  var host = String(value || "").trim();
  var end;
  var port;

  if (!host) {
    return String(PORT);
  }

  if (host.charAt(0) === "[") {
    end = host.indexOf("]");
    if (end >= 0 && host.charAt(end + 1) === ":") {
      port = host.slice(end + 2);
      return port || String(PORT);
    }
    return String(PORT);
  }

  if ((host.match(/:/g) || []).length === 1) {
    port = host.split(":")[1];
    return port || String(PORT);
  }

  return String(PORT);
}

function urlHost(address) {
  address = String(address || "");
  if (address.indexOf(":") !== -1 && address.charAt(0) !== "[") {
    return "[" + address + "]";
  }
  return address;
}

function firstLocalAddress() {
  var addresses = localAddresses();
  return addresses.length ? addresses[0] : "";
}

function networkLabel(address) {
  address = String(address || "").toLowerCase();
  if (!address || address === "localhost" || address === "127.0.0.1" || address === "::1") {
    return "This Mac";
  }
  if (isTailscaleAddress(address)) {
    return "Tailscale";
  }
  if (address.indexOf("192.168.") === 0 || address.indexOf("10.") === 0 || /^172\.(1[6-9]|2[0-9]|3[0-1])\./.test(address)) {
    return "Local network";
  }
  return "Private network";
}

function isTailscaleAddress(address) {
  var parts = String(address || "").split(".");
  var second;

  if (parts.length !== 4 || parts[0] !== "100") {
    return false;
  }

  second = Number(parts[1]);
  return second >= 64 && second <= 127;
}

function activeInstructionCount(instructions) {
  var count = 0;
  var i;
  for (i = 0; i < instructions.length; i += 1) {
    if (instructions[i].status === "queued") {
      count += 1;
    }
  }
  return count;
}

function upsertTask(input) {
  var tasks = readTasks();
  var id = cleanId(input.id || input.taskId || "current", "current");
  var index = -1;
  var previous = { id: id };
  var i;
  var next;

  for (i = 0; i < tasks.length; i += 1) {
    if (tasks[i].id === id) {
      index = i;
      previous = tasks[i];
      break;
    }
  }

  input.id = id;
  next = normalizeTask(input, previous, true);

  if (index >= 0) {
    tasks[index] = next;
  } else {
    tasks.push(next);
  }

  tasks = sortTasks(tasks).slice(0, 30);
  writeTasks(tasks);
  writeStatus(statusFromTasks(tasks));
  return next;
}

function normalizeStatus(input, updateClock) {
  var previous = readStatusSafe();
  var next = {};
  var state = String(input.state || previous.state || "idle").toLowerCase();

  if (!states[state]) {
    state = "idle";
  }

  next.state = state;
  next.title = cleanText(input.title, previous.title || "Blinky Codex ScreenPet", 40);
  next.task = cleanText(input.task, previous.task || "Waiting for task", 64);
  next.message = cleanText(input.message, previous.message || "", 72);
  next.detail = cleanText(input.detail, previous.detail || "", 120);
  next.progress = clampProgress(input.progress, previous.progress || 0);
  next.updatedAt = updateClock ? new Date().toISOString() : input.updatedAt || previous.updatedAt || new Date().toISOString();
  next.startedAt = input.startedAt || previous.startedAt || next.updatedAt;

  if (updateClock && state !== previous.state) {
    next.startedAt = next.updatedAt;
  }

  if (state === "done" && typeof input.progress === "undefined") {
    next.progress = 100;
  }

  if (state === "idle" && typeof input.progress === "undefined") {
    next.progress = 0;
  }

  return next;
}

function readStatusSafe() {
  try {
    if (!fs.existsSync(STATUS_FILE)) {
      return defaultStatus;
    }
    return JSON.parse(fs.readFileSync(STATUS_FILE, "utf8"));
  } catch (err) {
    return defaultStatus;
  }
}

function cleanText(value, fallback, limit) {
  var text = typeof value === "undefined" || value === null ? fallback : String(value);
  text = text.replace(/[\r\n\t]+/g, " ").replace(/\s\s+/g, " ").trim();
  if (text.length > limit) {
    text = text.slice(0, limit - 1) + "...";
  }
  return text;
}

function clampProgress(value, fallback) {
  var n = Number(value);
  if (!isFinite(n)) {
    n = Number(fallback) || 0;
  }
  if (n < 0) {
    return 0;
  }
  if (n > 100) {
    return 100;
  }
  return Math.round(n);
}

function sendJson(res, statusCode, payload) {
  var body = JSON.stringify(payload);
  res.writeHead(statusCode, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    "Content-Length": Buffer.byteLength(body)
  });
  res.end(body);
}

function sendText(res, statusCode, body) {
  res.writeHead(statusCode, {
    "Content-Type": "text/plain; charset=utf-8",
    "Cache-Control": "no-store"
  });
  res.end(body);
}

function sendHtml(res, statusCode, body) {
  res.writeHead(statusCode, {
    "Content-Type": "text/html; charset=utf-8",
    "Cache-Control": "no-store",
    "Content-Length": Buffer.byteLength(body)
  });
  res.end(body);
}

function sendSetupLocalOnly(res) {
  sendHtml(res, 403, [
    '<!doctype html>',
    '<html>',
    '<head>',
    '<meta charset="utf-8">',
    '<meta name="viewport" content="width=device-width, initial-scale=1">',
    '<title>Setup unavailable</title>',
    '<style>',
    'body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#eef3f8;color:#172033;font-family:-apple-system,BlinkMacSystemFont,"SF Pro Text","Helvetica Neue",Arial,Helvetica,sans-serif}',
    'main{max-width:520px;padding:28px}',
    'h1{margin:0 0 10px;font-size:28px;line-height:1.1}',
    'p{margin:0;color:#5d687a;font-size:16px;line-height:1.45}',
    '</style>',
    '</head>',
    '<body>',
    '<main>',
    '<h1>Setup only available on this Mac</h1>',
    '<p>Open http://localhost:' + PORT + '/setup on the Mac running Blinky Codex ScreenPet.</p>',
    '</main>',
    '</body>',
    '</html>'
  ].join(""));
}

function serveStatic(req, res, pathname) {
  var aliased = staticAliasPath(pathname);
  var filePath = aliased || (pathname === "/" ? path.join(PUBLIC_DIR, "index.html") : path.join(PUBLIC_DIR, pathname));
  var resolved = path.resolve(filePath);

  if (resolved.indexOf(PUBLIC_DIR) !== 0) {
    sendText(res, 403, "Forbidden");
    return;
  }

  fs.readFile(resolved, function (err, data) {
    if (err) {
      sendText(res, 404, "Not found");
      return;
    }

    res.writeHead(200, {
      "Content-Type": mimeType(resolved),
      "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
      "Pragma": "no-cache",
      "Expires": "0"
    });
    res.end(data);
  });
}

function staticAliasPath(pathname) {
  var appleTouchIconAliases = {
    "/apple-touch-icon.png": true,
    "/apple-touch-icon-precomposed.png": true,
    "/apple-touch-icon-120x120.png": true,
    "/apple-touch-icon-152x152.png": true,
    "/apple-touch-icon-167x167.png": true,
    "/apple-touch-icon-180x180.png": true
  };

  if (appleTouchIconAliases[pathname]) {
    return path.join(PUBLIC_DIR, "blinky-mobile-touch-icon-20260527.png");
  }
  if (pathname === "/favicon.ico") {
    return path.join(PUBLIC_DIR, "blinky-mobile-favicon-20260527.ico");
  }
  return "";
}

function mimeType(filePath) {
  var ext = path.extname(filePath).toLowerCase();
  if (ext === ".html") {
    return "text/html; charset=utf-8";
  }
  if (ext === ".css") {
    return "text/css; charset=utf-8";
  }
  if (ext === ".js") {
    return "application/javascript; charset=utf-8";
  }
  if (ext === ".json") {
    return "application/json; charset=utf-8";
  }
  if (ext === ".png") {
    return "image/png";
  }
  if (ext === ".ico") {
    return "image/x-icon";
  }
  if (ext === ".svg") {
    return "image/svg+xml";
  }
  if (ext === ".webmanifest") {
    return "application/manifest+json; charset=utf-8";
  }
  return "application/octet-stream";
}

function readBody(req, done) {
  var chunks = [];
  var size = 0;

  req.on("data", function (chunk) {
    size += chunk.length;
    if (size > 1024 * 64) {
      req.destroy();
      return;
    }
    chunks.push(chunk);
  });

  req.on("end", function () {
    var raw = Buffer.concat(chunks).toString("utf8");
    var contentType = req.headers["content-type"] || "";

    if (contentType.indexOf("application/json") !== -1) {
      try {
        done(null, JSON.parse(raw || "{}"));
      } catch (err) {
        done(err);
      }
      return;
    }

    done(null, querystring.parse(raw));
  });

  req.on("error", done);
}

function parseRequestUrl(req) {
  var parsed = new URL(req.url || "/", "http://127.0.0.1");
  var query = {};

  parsed.searchParams.forEach(function (value, key) {
    if (Object.prototype.hasOwnProperty.call(query, key)) {
      if (Array.isArray(query[key])) {
        query[key].push(value);
      } else {
        query[key] = [query[key], value];
      }
      return;
    }

    query[key] = value;
  });

  return {
    pathname: parsed.pathname,
    query: query
  };
}

function packageVersion() {
  try {
    return JSON.parse(fs.readFileSync(PACKAGE_FILE, "utf8")).version || "";
  } catch (err) {
    return "";
  }
}

function setupInfo(req) {
  var auth = authConfig();
  var networkEntries = localNetworkEntries();
  var prefs = readSetupPrefs();
  var local = isLocalRequest(req);
  var phoneUrls = [];

  networkEntries.forEach(function (entry) {
    phoneUrls.push({
      label: entry.label,
      kind: entry.kind === "tailscale" ? "tailscale" : "local",
      interfaceName: entry.name,
      interfaceKind: entry.kind,
      url: "http://" + entry.address + ":" + PORT + "/"
    });
  });

  return {
    app: {
      name: "Blinky Codex ScreenPet",
      version: packageVersion(),
      demoMode: DEMO_MODE
    },
    auth: {
      enabled: auth.enabled,
      pinVisible: local && auth.enabled,
      pin: local && auth.enabled ? auth.pin : "",
      source: auth.enabled ? auth.source : "disabled",
      custom: !!auth.custom,
      stable: true,
      canChangePin: local && auth.enabled && auth.source !== "env",
      changeDisabledReason: auth.enabled && auth.source === "env" ? "PET_AUTH_PIN is set in the environment." : ""
    },
    urls: {
      setup: "http://localhost:" + PORT + "/setup",
      dashboard: "http://127.0.0.1:" + PORT + "/",
      phone: phoneUrls,
      manualTunnel: prefs.manualTunnelUrl,
      remote: {
        manualTunnelUrl: prefs.manualTunnelUrl
      }
    },
    permissions: {
      remoteControl: remoteControlPermissionStatus()
    },
    checks: setupChecks(),
    updatedAt: new Date().toISOString()
  };
}

function setupChecks() {
  var remoteControl = remoteControlPermissionStatus();
  return [
    {
      id: "node",
      label: "Node.js",
      ok: Number(process.versions.node.split(".")[0]) >= 18,
      detail: process.version
    },
    {
      id: "codex-app",
      label: "Codex Desktop app",
      ok: fs.existsSync("/Applications/Codex.app"),
      detail: fs.existsSync("/Applications/Codex.app") ? "installed" : "not found in /Applications"
    },
    {
      id: "codex-state",
      label: "Codex state database",
      ok: fs.existsSync(CODEX_STATE_DB),
      detail: fs.existsSync(CODEX_STATE_DB) ? "available" : "not found"
    },
    {
      id: "codex-logs",
      label: "Codex logs database",
      ok: fs.existsSync(CODEX_LOGS_DB),
      detail: fs.existsSync(CODEX_LOGS_DB) ? "available" : "not found"
    },
    {
      id: "network",
      label: "Phone network address",
      ok: localAddresses().length > 0,
      detail: localAddresses().length ? localAddresses().join(", ") : "no private network address found"
    },
    {
      id: "remote-control",
      label: "Remote control permission",
      ok: remoteControl.ok,
      detail: remoteControl.detail
    }
  ];
}

function remoteControlPermissionStatus() {
  var now = Date.now();
  var menuStatus;
  var trusted = false;
  var detail;
  var source = "";

  if (process.platform !== "darwin") {
    return {
      id: "remote-control",
      ok: false,
      available: false,
      detail: "macOS only",
      action: ""
    };
  }

  if (remoteControlPermissionCache.value && now - remoteControlPermissionCache.checkedAt < 5000) {
    return remoteControlPermissionCache.value;
  }

  menuStatus = readMenuRemoteControlPermissionStatus(now);
  if (menuStatus) {
    trusted = menuStatus.ok === true;
    source = "menu-app";
  }

  detail = trusted ?
    "allowed for visible Desktop UI delivery" :
    "allow Blinky Codex ScreenPet.app in Privacy & Security > Accessibility";

  remoteControlPermissionCache.value = {
    id: "remote-control",
    ok: trusted,
    available: true,
    detail: detail,
    source: source || "untrusted",
    action: trusted ? "" : "open-settings"
  };
  remoteControlPermissionCache.checkedAt = now;
  return remoteControlPermissionCache.value;
}

function readMenuRemoteControlPermissionStatus(now) {
  var paths = [LOCAL_PERMISSION_STATUS_FILE, MENU_PERMISSION_STATUS_FILE];
  var i;
  var file;
  var stat;
  var parsed;
  var updatedAt;

  for (i = 0; i < paths.length; i += 1) {
    file = paths[i];
    try {
      stat = fs.statSync(file);
      if (now - stat.mtimeMs > 15000) {
        continue;
      }
      parsed = JSON.parse(fs.readFileSync(file, "utf8"));
      updatedAt = Date.parse(parsed.updatedAt || "") || 0;
      if (updatedAt && now - updatedAt > 15000) {
        continue;
      }
      if (parsed && parsed.id === "remote-control" && parsed.source === "menu-app") {
        return {
          ok: parsed.ok === true,
          detail: cleanText(parsed.detail, "", 120),
          updatedAt: parsed.updatedAt || "",
          appPath: cleanText(parsed.appPath, "", 240)
        };
      }
    } catch (err) {
    }
  }

  return null;
}

function openRemoteControlPermissionSettings() {
  if (process.platform !== "darwin") {
    return false;
  }

  try {
    childProcess.execFile("open", [
      "x-apple.systempreferences:com.apple.preference.security?Privacy_Accessibility"
    ], {
      timeout: 3000
    }, function () {});
    return true;
  } catch (err) {
    return false;
  }
}

function localAddresses() {
  return localNetworkEntries().map(function (entry) {
    return entry.address;
  });
}

function localNetworkEntries() {
  if (DEMO_MODE && PUBLIC_DEMO_ASSETS) {
    return [
      {
        name: "en1",
        address: "192.168.0.42",
        kind: "wifi",
        label: "Wi-Fi Local network"
      },
      {
        name: "utun0",
        address: "100.64.0.42",
        kind: "tailscale",
        label: "Tailscale"
      }
    ];
  }

  var nets = os.networkInterfaces();
  var hardwarePorts = networkHardwarePorts();
  var out = [];
  Object.keys(nets).forEach(function (name) {
    nets[name].forEach(function (net) {
      var kind;
      if (net.family === "IPv4" && !net.internal) {
        kind = networkInterfaceKind(name, net.address, hardwarePorts);
        out.push({
          name: name,
          address: net.address,
          kind: kind,
          label: networkInterfaceLabel(kind)
        });
      }
    });
  });
  return out;
}

function networkHardwarePorts() {
  var output;
  var currentPort = "";
  var lines;
  var i;
  var match;

  if (networkHardwarePortCache) {
    return networkHardwarePortCache;
  }

  networkHardwarePortCache = {};
  if (process.platform !== "darwin") {
    return networkHardwarePortCache;
  }

  try {
    output = childProcess.execFileSync("networksetup", ["-listallhardwareports"], {
      encoding: "utf8",
      timeout: 800
    });
  } catch (err) {
    return networkHardwarePortCache;
  }

  lines = output.split(/\r?\n/);
  for (i = 0; i < lines.length; i += 1) {
    match = lines[i].match(/^Hardware Port:\s*(.+)$/);
    if (match) {
      currentPort = match[1];
      continue;
    }

    match = lines[i].match(/^Device:\s*(.+)$/);
    if (match && currentPort) {
      networkHardwarePortCache[match[1]] = currentPort;
    }
  }

  return networkHardwarePortCache;
}

function networkInterfaceKind(name, address, hardwarePorts) {
  var hardwarePort = String(hardwarePorts[name] || "").toLowerCase();

  if (isTailscaleAddress(address)) {
    return "tailscale";
  }

  if (hardwarePort.indexOf("wi-fi") !== -1 || hardwarePort.indexOf("wifi") !== -1 || hardwarePort.indexOf("airport") !== -1) {
    return "wifi";
  }

  if (hardwarePort.indexOf("ethernet") !== -1 || hardwarePort.indexOf("thunderbolt") !== -1) {
    return "ethernet";
  }

  return "local";
}

function networkInterfaceLabel(kind) {
  if (kind === "tailscale") {
    return "Tailscale";
  }

  if (kind === "wifi") {
    return "Wi-Fi Local network";
  }

  if (kind === "ethernet") {
    return "Ethernet Local network";
  }

  return "Local network";
}

function filteredInstructions(query) {
  var instructions = readInstructions();
  var taskId = query && query.taskId ? cleanId(query.taskId, "") : "";
  var status = query && query.status ? cleanInstructionStatus(query.status) : "";
  var out = [];
  var i;
  var item;

  for (i = 0; i < instructions.length; i += 1) {
    item = instructions[i];
    if (taskId && item.taskId !== taskId) {
      continue;
    }
    if (status && item.status !== status) {
      continue;
    }
    out.push(item);
  }

  return out;
}

function markInstruction(input) {
  var instructions = readInstructions();
  var id = cleanId(input.id || input.instructionId, "");
  var status = cleanInstructionStatus(input.status || "sent");
  var now = new Date().toISOString();
  var i;

  if (!id) {
    return null;
  }

  for (i = 0; i < instructions.length; i += 1) {
    if (instructions[i].id === id) {
      instructions[i].status = status;
      instructions[i].updatedAt = now;
      writeInstructions(instructions);
      return instructions[i];
    }
  }

  return null;
}

function createCodexRpcClient() {
  var client = {
    child: null,
    buffer: "",
    closed: false,
    nextId: 1,
    pending: {},
    stderr: "",
    ready: null
  };

  client.child = childProcess.spawn(CODEX_BIN, ["app-server", "--listen", "stdio://"], {
    cwd: ROOT,
    stdio: ["pipe", "pipe", "pipe"]
  });

  client.child.stdout.setEncoding("utf8");
  client.child.stdout.on("data", function (chunk) {
    handleCodexRpcData(client, chunk);
  });

  client.child.stderr.setEncoding("utf8");
  client.child.stderr.on("data", function (chunk) {
    client.stderr = cleanText((client.stderr + String(chunk)).slice(-600), "", 600);
  });

  client.child.stdin.on("error", function (err) {
    closeCodexRpcClient(client, err);
  });

  client.child.on("error", function (err) {
    closeCodexRpcClient(client, err);
  });

  client.child.on("exit", function (code, signal) {
    closeCodexRpcClient(client, new Error("Codex bridge stopped (" + (signal || code || "exit") + ")"));
  });

  client.request = function (method, params, timeoutMs) {
    return codexRpcRequest(client, method, params, timeoutMs);
  };

  client.notify = function (method, params) {
    writeCodexRpc(client, {
      method: method,
      params: params
    });
  };

  client.ready = client.request("initialize", {
    clientInfo: {
      name: "codex-iphone-pet",
      version: "0.1.0"
    },
    capabilities: {
      experimentalApi: true,
      requestAttestation: false,
      optOutNotificationMethods: [
        "item/agentMessage/delta",
        "item/reasoning/textDelta",
        "item/reasoning/summaryTextDelta",
        "command/exec/outputDelta",
        "process/outputDelta"
      ]
    }
  }, 10000).then(function () {
    client.notify("initialized");
    return client;
  });

  return client;
}

function ensureCodexRpcClient() {
  var client;

  if (codexRpc && !codexRpc.closed) {
    return codexRpc.ready;
  }

  if (!fs.existsSync(CODEX_BIN)) {
    return Promise.reject(new Error("Codex app was not found."));
  }

  client = createCodexRpcClient();
  codexRpc = client;
  client.ready = client.ready.catch(function (err) {
    if (codexRpc === client) {
      codexRpc = null;
    }
    throw err;
  });
  return client.ready;
}

function codexRpcRequest(client, method, params, timeoutMs) {
  return new Promise(function (resolve, reject) {
    var id;
    var timer;

    if (!client || client.closed || !client.child || !client.child.stdin.writable) {
      reject(new Error("Codex bridge is not connected."));
      return;
    }

    id = client.nextId;
    client.nextId += 1;
    timer = setTimeout(function () {
      delete client.pending[id];
      reject(new Error(method + " timed out."));
    }, timeoutMs || CODEX_DELIVERY_TIMEOUT_MS);

    client.pending[id] = {
      method: method,
      resolve: resolve,
      reject: reject,
      timer: timer
    };

    try {
      writeCodexRpc(client, {
        id: id,
        method: method,
        params: params
      });
    } catch (err) {
      clearTimeout(timer);
      delete client.pending[id];
      reject(err);
    }
  });
}

function writeCodexRpc(client, message) {
  if (!client || client.closed || !client.child || !client.child.stdin.writable) {
    throw new Error("Codex bridge is not connected.");
  }
  client.child.stdin.write(JSON.stringify(message) + "\n");
}

function handleCodexRpcData(client, chunk) {
  var lines;
  var i;

  client.buffer += String(chunk);
  lines = client.buffer.split(/\n/);
  client.buffer = lines.pop();

  for (i = 0; i < lines.length; i += 1) {
    handleCodexRpcLine(client, lines[i]);
  }
}

function handleCodexRpcLine(client, line) {
  var message;
  var pending;

  line = String(line || "").trim();
  if (!line) {
    return;
  }

  try {
    message = JSON.parse(line);
  } catch (err) {
    return;
  }

  if (typeof message.id !== "undefined" && client.pending[message.id]) {
    pending = client.pending[message.id];
    delete client.pending[message.id];
    clearTimeout(pending.timer);
    if (message.error) {
      pending.reject(codexErrorFromRpc(message.error, pending.method));
    } else {
      pending.resolve(message.result);
    }
    return;
  }

  if (message.method === "thread/name/updated") {
    updateCodexThreadTitleFromNotification(message.params || {});
    return;
  }

  if (typeof message.id !== "undefined" && message.method) {
    rejectUnsupportedCodexServerRequest(client, message);
  }
}

function rejectUnsupportedCodexServerRequest(client, message) {
  try {
    writeCodexRpc(client, {
      id: message.id,
      error: {
        code: -32601,
        message: "Blinky Codex ScreenPet can send instructions, but cannot answer interactive Codex prompts."
      }
    });
  } catch (err) {
  }
}

function closeCodexRpcClient(client, err) {
  var ids;
  var i;
  var pending;

  if (!client || client.closed) {
    return;
  }

  client.closed = true;
  ids = Object.keys(client.pending);
  for (i = 0; i < ids.length; i += 1) {
    pending = client.pending[ids[i]];
    clearTimeout(pending.timer);
    pending.reject(err || new Error("Codex bridge stopped."));
  }
  client.pending = {};

  if (codexRpc === client) {
    codexRpc = null;
  }
}

function codexErrorFromRpc(error, method) {
  var message = "";
  if (error && error.message) {
    message = error.message;
  } else if (typeof error === "string") {
    message = error;
  }
  if (!message) {
    message = method + " failed.";
  }
  return new Error(message);
}

function isCodexThreadId(value) {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(String(value || ""));
}

function openCodexDesktopThread(threadId, reason, options) {
  var now = new Date().getTime();
  var last;
  var waitMs;
  var timer;
  var syncOptions = options || {};

  if (!CODEX_DESKTOP_SYNC || !isCodexThreadId(threadId)) {
    return false;
  }

  last = desktopSyncs[threadId] || 0;
  waitMs = Math.max(0, DESKTOP_SYNC_THROTTLE_MS - (now - last));
  if (waitMs > 0) {
    if (desktopSyncTimers[threadId]) {
      clearTimeout(desktopSyncTimers[threadId]);
    }
    timer = setTimeout(function () {
      delete desktopSyncTimers[threadId];
      performCodexDesktopOpen(threadId, reason || "queued", syncOptions);
    }, waitMs);
    if (timer.unref) {
      timer.unref();
    }
    desktopSyncTimers[threadId] = timer;
    return true;
  }

  performCodexDesktopOpen(threadId, reason, syncOptions);
  return true;
}

function performCodexDesktopOpen(threadId, reason, options) {
  var forceRefresh = DESKTOP_SYNC_FORCE_REFRESH || !!(options && options.forceRefresh);
  desktopSyncs[threadId] = new Date().getTime();
  scheduleCodexDesktopInvalidates(threadId, reason || "sync", 0);

  if (forceRefresh) {
    openCodexUrl("codex://threads/new", "refresh", threadId);
    setTimeout(function () {
      scheduleCodexDesktopOpenSequence(threadId, reason || "sync", 0);
      scheduleCodexDesktopHardReload(threadId, reason);
    }, DESKTOP_SYNC_FORCE_REFRESH_DELAY_MS);
    return;
  }

  scheduleCodexDesktopOpenSequence(threadId, reason || "sync", 0);
  scheduleCodexDesktopHardReload(threadId, reason);
}

function openCodexUrl(targetUrl, reason, threadId) {
  childProcess.execFile("osascript", ["-e", "tell application \"Codex\" to activate"], {
    timeout: 3000
  }, function () {
    childProcess.execFile("open", [targetUrl], {
      timeout: 3000
    }, function (err) {
      if (err) {
        console.warn("Codex desktop sync failed: " + friendlyDeliveryError(err));
        return;
      }
      if (reason) {
        console.log("Codex desktop sync: " + reason + " " + threadId);
      }
    });
  });
}

function scheduleCodexDesktopOpenSequence(threadId, reason, baseDelayMs) {
  var delays = DESKTOP_SYNC_SECOND_OPEN ? DESKTOP_SYNC_OPEN_DELAYS_MS : [0];
  var i;

  for (i = 0; i < delays.length; i += 1) {
    scheduleCodexDesktopOpenAt(threadId, reason, baseDelayMs + delays[i], i);
  }
}

function scheduleCodexDesktopOpenAt(threadId, reason, delayMs, index) {
  var timer = setTimeout(function () {
    var suffix = index > 0 ? "-confirm-" + (index + 1) : "";
    openCodexUrl("codex://threads/" + threadId, (reason || "sync") + suffix, threadId);
  }, Math.max(0, delayMs));

  if (timer.unref) {
    timer.unref();
  }
}

function scheduleCodexDesktopInvalidates(threadId, reason, baseDelayMs) {
  var i;

  if (!CODEX_DESKTOP_IPC_SYNC || !isCodexThreadId(threadId)) {
    return;
  }

  for (i = 0; i < DESKTOP_SYNC_INVALIDATE_DELAYS_MS.length; i += 1) {
    scheduleCodexDesktopInvalidateAt(threadId, reason, baseDelayMs + DESKTOP_SYNC_INVALIDATE_DELAYS_MS[i], i);
  }
}

function scheduleCodexDesktopInvalidateAt(threadId, reason, delayMs, index) {
  var timer = setTimeout(function () {
    sendCodexDesktopInvalidate(threadId, (reason || "sync") + "-invalidate-" + (index + 1));
  }, Math.max(0, delayMs));

  if (timer.unref) {
    timer.unref();
  }
}

function sendCodexDesktopInvalidate(threadId, reason) {
  var socket;
  var requestId;
  var initialized = false;
  var closed = false;
  var buffer = Buffer.alloc(0);
  var expected = null;
  var timeout;

  if (!CODEX_DESKTOP_IPC_SYNC || !CODEX_DESKTOP_IPC_SOCKET || !isCodexThreadId(threadId)) {
    return false;
  }

  if (process.platform !== "win32" && !fs.existsSync(CODEX_DESKTOP_IPC_SOCKET)) {
    return false;
  }

  requestId = "iphone-pet-init-" + new Date().getTime() + "-" + Math.floor(Math.random() * 10000);
  socket = net.connect(CODEX_DESKTOP_IPC_SOCKET);

  function finish(err) {
    if (closed) {
      return;
    }
    closed = true;
    clearTimeout(timeout);
    try {
      socket.end();
    } catch (endErr) {
    }
    if (err) {
      console.warn("Codex desktop IPC sync failed: " + friendlyDeliveryError(err));
    } else {
      console.log("Codex desktop IPC sync: " + reason + " " + threadId);
    }
  }

  function writeIpcMessage(message) {
    socket.write(frameIpcMessage(message));
  }

  function sendInvalidates(clientId) {
    var messages = codexDesktopInvalidateMessages(threadId, clientId);
    var timer;
    var i;
    for (i = 0; i < messages.length; i += 1) {
      writeIpcMessage(messages[i]);
    }
    timer = setTimeout(function () {
      finish(null);
    }, 80);
    if (timer.unref) {
      timer.unref();
    }
  }

  function readMessages(chunk) {
    var frame;
    var message;

    if (closed || !chunk || chunk.length === 0) {
      return;
    }

    buffer = Buffer.concat([buffer, chunk]);
    for (;;) {
      if (expected === null) {
        if (buffer.length < 4) {
          return;
        }
        expected = buffer.readUInt32LE(0);
        buffer = buffer.subarray(4);
      }
      if (buffer.length < expected) {
        return;
      }
      frame = buffer.subarray(0, expected);
      buffer = buffer.subarray(expected);
      expected = null;
      try {
        message = JSON.parse(frame.toString("utf8"));
      } catch (err) {
        finish(err);
        return;
      }
      if (!initialized && message.type === "response" && message.requestId === requestId) {
        initialized = true;
        sendInvalidates(message.result && message.result.clientId ? message.result.clientId : "iphone-pet");
        return;
      }
    }
  }

  timeout = setTimeout(function () {
    finish(new Error("desktop IPC timeout"));
  }, CODEX_DESKTOP_IPC_TIMEOUT_MS);
  if (timeout.unref) {
    timeout.unref();
  }

  socket.on("connect", function () {
    writeIpcMessage({
      type: "request",
      requestId: requestId,
      method: "initialize",
      params: {
        clientType: "iphone-pet"
      }
    });
  });
  socket.on("data", readMessages);
  socket.on("error", finish);
  socket.on("close", function () {
    if (!closed && !initialized) {
      finish(new Error("desktop IPC closed"));
    }
  });

  return true;
}

function codexDesktopIpcRequest(method, params, timeoutMs) {
  return new Promise(function (resolve, reject) {
    var socket;
    var initRequestId;
    var requestId;
    var clientId = "";
    var initialized = false;
    var requestSent = false;
    var closed = false;
    var buffer = Buffer.alloc(0);
    var expected = null;
    var timeout;

    if (!CODEX_DESKTOP_IPC_SYNC || !CODEX_DESKTOP_IPC_SOCKET) {
      reject(new Error("desktop IPC disabled"));
      return;
    }

    if (process.platform !== "win32" && !fs.existsSync(CODEX_DESKTOP_IPC_SOCKET)) {
      reject(new Error("desktop IPC socket not found"));
      return;
    }

    initRequestId = newIpcRequestId("iphone-pet-init");
    requestId = newIpcRequestId("iphone-pet-request");
    socket = net.connect(CODEX_DESKTOP_IPC_SOCKET);

    function finish(err, result) {
      if (closed) {
        return;
      }
      closed = true;
      clearTimeout(timeout);
      try {
        socket.end();
      } catch (endErr) {
      }
      if (err) {
        reject(err);
        return;
      }
      resolve(result);
    }

    function writeIpcMessage(message) {
      socket.write(frameIpcMessage(message));
    }

    function sendRequest() {
      requestSent = true;
      writeIpcMessage({
        type: "request",
        requestId: requestId,
        sourceClientId: clientId || "iphone-pet",
        version: codexDesktopRequestVersion(method),
        method: method,
        params: params || {}
      });
    }

    function handleResponse(message) {
      if (!initialized && message.requestId === initRequestId) {
        if (message.resultType === "error" || message.error) {
          finish(new Error(String(message.error || "desktop IPC initialize failed")));
          return;
        }
        initialized = true;
        clientId = message.result && message.result.clientId ? message.result.clientId : "iphone-pet";
        sendRequest();
        return;
      }

      if (requestSent && message.requestId === requestId) {
        if (message.resultType === "error" || message.error) {
          finish(new Error(String(message.error || method + " failed")));
          return;
        }
        finish(null, message.result);
      }
    }

    function readMessages(chunk) {
      var frame;
      var message;

      if (closed || !chunk || chunk.length === 0) {
        return;
      }

      buffer = Buffer.concat([buffer, chunk]);
      for (;;) {
        if (expected === null) {
          if (buffer.length < 4) {
            return;
          }
          expected = buffer.readUInt32LE(0);
          buffer = buffer.subarray(4);
        }
        if (buffer.length < expected) {
          return;
        }
        frame = buffer.subarray(0, expected);
        buffer = buffer.subarray(expected);
        expected = null;
        try {
          message = JSON.parse(frame.toString("utf8"));
        } catch (err) {
          finish(err);
          return;
        }
        if (message && message.type === "response") {
          handleResponse(message);
        }
      }
    }

    timeout = setTimeout(function () {
      finish(new Error(method + " desktop IPC timeout"));
    }, timeoutMs || CODEX_DESKTOP_IPC_REQUEST_TIMEOUT_MS);
    if (timeout.unref) {
      timeout.unref();
    }

    socket.on("connect", function () {
      writeIpcMessage({
        type: "request",
        requestId: initRequestId,
        method: "initialize",
        params: {
          clientType: "iphone-pet"
        }
      });
    });
    socket.on("data", readMessages);
    socket.on("error", function (err) {
      finish(err);
    });
    socket.on("close", function () {
      if (!closed) {
        finish(new Error(initialized ? "desktop IPC closed" : "desktop IPC closed before initialize"));
      }
    });
  });
}

function newIpcRequestId(prefix) {
  return prefix + "-" + new Date().getTime() + "-" + Math.floor(Math.random() * 100000);
}

function codexDesktopRequestVersion(method) {
  return codexDesktopBroadcastVersion(method);
}

function codexDesktopInvalidateMessages(threadId, clientId) {
  var source = clientId || "iphone-pet";
  return [
    codexDesktopBroadcast(source, "query-cache-invalidate", { queryKey: [] }),
    codexDesktopBroadcast(source, "query-cache-invalidate", { queryKey: ["threads"] }),
    codexDesktopBroadcast(source, "query-cache-invalidate", { queryKey: ["thread"] }),
    codexDesktopBroadcast(source, "query-cache-invalidate", { queryKey: ["thread", threadId] }),
    codexDesktopBroadcast(source, "query-cache-invalidate", { queryKey: ["conversation", threadId] }),
    codexDesktopBroadcast(source, "thread-read-state-changed", {
      conversationId: threadId,
      hasUnreadTurn: false
    })
  ];
}

function codexDesktopBroadcast(clientId, method, params) {
  return {
    type: "broadcast",
    method: method,
    sourceClientId: clientId,
    version: codexDesktopBroadcastVersion(method),
    params: params
  };
}

function codexDesktopBroadcastVersion(method) {
  var versions = {
    "thread-stream-state-changed": 6,
    "thread-read-state-changed": 1,
    "thread-archived": 2,
    "thread-unarchived": 1,
    "thread-follower-start-turn": 1,
    "thread-follower-compact-thread": 1,
    "thread-follower-interrupt-turn": 1,
    "thread-follower-set-model-and-reasoning": 1,
    "thread-follower-set-collaboration-mode": 1,
    "thread-follower-edit-last-user-turn": 1,
    "thread-follower-command-approval-decision": 1,
    "thread-follower-file-approval-decision": 1,
    "thread-follower-permissions-request-approval-response": 1,
    "thread-follower-submit-user-input": 1,
    "thread-follower-submit-mcp-server-elicitation-response": 1,
    "thread-follower-set-queued-follow-ups-state": 1,
    "thread-queued-followups-changed": 1
  };

  return typeof versions[method] === "number" ? versions[method] : 0;
}

function frameIpcMessage(message) {
  var json = JSON.stringify(message);
  var length = Buffer.byteLength(json, "utf8");
  var frame = Buffer.alloc(4 + length);
  frame.writeUInt32LE(length, 0);
  frame.write(json, 4, "utf8");
  return frame;
}

function scheduleCodexDesktopHardReload(threadId, reason) {
  var timer;

  if (!DESKTOP_SYNC_HARD_RELOAD || !isCodexThreadId(threadId)) {
    return;
  }

  timer = setTimeout(function () {
    hardReloadCodexDesktop(threadId, reason);
  }, DESKTOP_SYNC_HARD_RELOAD_DELAY_MS);
  if (timer.unref) {
    timer.unref();
  }
}

function scheduleCodexDesktopSecondOpen(threadId, reason) {
  var timer;

  if (!DESKTOP_SYNC_SECOND_OPEN || !isCodexThreadId(threadId)) {
    return;
  }

  timer = setTimeout(function () {
    openCodexUrl("codex://threads/" + threadId, (reason || "sync") + "-confirm", threadId);
  }, DESKTOP_SYNC_SECOND_OPEN_DELAY_MS);
  if (timer.unref) {
    timer.unref();
  }
}

function hardReloadCodexDesktop(threadId, reason) {
  var swiftScript = [
    "import CoreGraphics",
    "import Foundation",
    "let src = CGEventSource(stateID: .hidSystemState)",
    "let key: CGKeyCode = 15",
    "let down = CGEvent(keyboardEventSource: src, virtualKey: key, keyDown: true)!",
    "down.flags = [.maskCommand, .maskControl]",
    "let up = CGEvent(keyboardEventSource: src, virtualKey: key, keyDown: false)!",
    "up.flags = [.maskCommand, .maskControl]",
    "down.post(tap: .cghidEventTap)",
    "usleep(50000)",
    "up.post(tap: .cghidEventTap)"
  ].join("; ");

  childProcess.execFile("osascript", ["-e", "tell application \"Codex\" to activate"], {
    timeout: 3000
  }, function () {
    childProcess.execFile("swift", ["-e", swiftScript], {
      timeout: 5000
    }, function (err) {
      if (err) {
        console.warn("Codex desktop hard reload failed: " + friendlyDeliveryError(err));
        return;
      }
      console.log("Codex desktop hard reload: " + (reason || "sync") + " " + threadId);
    });
  });
}

function watchCodexTurnForDesktopSync(threadId, turnId, options) {
  var startedAt = new Date().getTime();
  var timer;

  if (!CODEX_DESKTOP_SYNC || !isCodexThreadId(threadId) || !turnId) {
    return;
  }

  timer = setInterval(function () {
    var row = readCodexThreadRow(threadId);
    var activity = row ? rolloutActivity(row.rollout_path) : null;

    if (activity && activity.lastCompleteTurnId === turnId) {
      clearInterval(timer);
      openCodexDesktopThread(threadId, "completed", options);
      return;
    }

    if (new Date().getTime() - startedAt > DESKTOP_SYNC_COMPLETE_TIMEOUT_MS) {
      clearInterval(timer);
    }
  }, 2000);

  if (timer.unref) {
    timer.unref();
  }
}

function readCodexThreadRow(threadId) {
  var query;
  var raw;
  var rows;

  if (!isCodexThreadId(threadId) || !fs.existsSync(CODEX_STATE_DB)) {
    return null;
  }

  query = [
    "SELECT id,rollout_path,cwd FROM threads WHERE id = ",
    sqlQuote(threadId),
    " LIMIT 1;"
  ].join("");

  try {
    raw = childProcess.execFileSync("sqlite3", ["-json", CODEX_STATE_DB, query], {
      encoding: "utf8",
      timeout: 1500
    });
    rows = JSON.parse(raw || "[]");
  } catch (err) {
    return null;
  }

  return rows && rows[0] ? rows[0] : null;
}

function readCodexThreadCwd(threadId) {
  var row = readCodexThreadRow(threadId);
  return row && row.cwd ? String(row.cwd) : "";
}

function sqlQuote(value) {
  return "'" + String(value || "").replace(/'/g, "''") + "'";
}

function delay(ms) {
  return new Promise(function (resolve) {
    setTimeout(resolve, Math.max(0, Number(ms) || 0));
  });
}

function execFilePromise(file, args, options) {
  return new Promise(function (resolve, reject) {
    childProcess.execFile(file, args || [], options || {}, function (err, stdout, stderr) {
      if (err) {
        err.stdout = stdout;
        err.stderr = stderr;
        reject(err);
        return;
      }
      resolve({
        stdout: stdout || "",
        stderr: stderr || ""
      });
    });
  });
}

function waitForCodexUserMessage(threadId, text, startedAt) {
  var deadline = new Date().getTime() + Math.max(1000, DESKTOP_UI_CONFIRM_TIMEOUT_MS || 10000);

  function check() {
    if (rolloutContainsUserMessage(threadId, text, startedAt)) {
      return Promise.resolve(true);
    }
    if (new Date().getTime() >= deadline) {
      return Promise.reject(new Error("Codex Desktop did not record the instruction in that thread."));
    }
    return delay(400).then(check);
  }

  return check();
}

function rolloutContainsUserMessage(threadId, text, startedAt) {
  var row = readCodexThreadRow(threadId);
  var expected = cleanMessageText(text);
  var lines;
  var i;
  var entry;
  var msg;
  var time;

  if (!row || !row.rollout_path || !fs.existsSync(row.rollout_path) || !expected) {
    return false;
  }

  try {
    lines = tailLines(row.rollout_path, 700, 12 * 1024 * 1024);
  } catch (err) {
    return false;
  }

  for (i = lines.length - 1; i >= 0; i -= 1) {
    entry = parseJsonLine(lines[i]);
    if (!entry) {
      continue;
    }
    time = Date.parse(entry.timestamp || "");
    if (startedAt && time && time < startedAt - 1000) {
      continue;
    }
    msg = messageFromRolloutEntry(entry);
    if (msg && msg.role === "user" && messageMatchesInstruction(msg.text, expected)) {
      return true;
    }
  }

  return false;
}

function messageMatchesInstruction(actual, expected) {
  actual = cleanMessageText(actual);
  expected = cleanMessageText(expected);
  if (!actual || !expected) {
    return false;
  }
  if (actual === expected) {
    return true;
  }
  return expected.length > 80 && actual.indexOf(expected.slice(0, 80)) !== -1;
}

function deliverInstructionViaCodexDesktopUi(threadId, text) {
  var startedAt = new Date().getTime();
  var permission;
  if (!CODEX_DESKTOP_UI_DELIVERY || !isCodexThreadId(threadId)) {
    return Promise.reject(new Error("desktop UI delivery disabled"));
  }
  if (process.platform !== "darwin") {
    return Promise.reject(new Error("desktop UI delivery only works on macOS"));
  }

  permission = remoteControlPermissionStatus();
  if (!permission.ok) {
    return Promise.reject(new Error("Mac Accessibility permission is not ready for visible Desktop UI delivery. Open setup on this Mac and allow Blinky Codex ScreenPet.app in Privacy & Security > Accessibility."));
  }

  return execFilePromise("open", ["codex://threads/" + threadId], {
    timeout: 3000
  }).then(function () {
    return delay(DESKTOP_UI_OPEN_DELAY_MS);
  }).then(function () {
    return sendTextThroughCodexDesktopUi(text);
  }).then(function () {
    return waitForCodexUserMessage(threadId, text, startedAt);
  }).then(function () {
    return {
      deliveryMethod: "desktop-ui",
      threadId: threadId,
      turnId: ""
    };
  });
}

function sendTextThroughCodexDesktopUi(text) {
  var xRatio = !isNaN(DESKTOP_UI_COMPOSER_X_RATIO) ? Math.max(0.2, Math.min(0.8, DESKTOP_UI_COMPOSER_X_RATIO)) : 0.42;
  var yOffset = !isNaN(DESKTOP_UI_COMPOSER_Y_OFFSET) ? Math.max(40, Math.min(180, DESKTOP_UI_COMPOSER_Y_OFFSET)) : 92;
  var source = [
    "import CoreGraphics",
    "import Foundation",
    "let text = ProcessInfo.processInfo.environment[\"PET_TEXT\"] ?? \"\"",
    "let list = CGWindowListCopyWindowInfo([.optionOnScreenOnly, .excludeDesktopElements], kCGNullWindowID) as? [[String: Any]] ?? []",
    "let wins = list.filter { ($0[kCGWindowOwnerName as String] as? String) == \"Codex\" && (($0[kCGWindowLayer as String] as? Int) ?? -1) == 0 }",
    "let win = wins.max { a, b in",
    "  let ab = a[kCGWindowBounds as String] as? [String: Any] ?? [:]",
    "  let bb = b[kCGWindowBounds as String] as? [String: Any] ?? [:]",
    "  let aa = ((ab[\"Width\"] as? Double) ?? 0) * ((ab[\"Height\"] as? Double) ?? 0)",
    "  let ba = ((bb[\"Width\"] as? Double) ?? 0) * ((bb[\"Height\"] as? Double) ?? 0)",
    "  return aa < ba",
    "}",
    "guard let bounds = win?[kCGWindowBounds as String] as? [String: Any] else { fatalError(\"No Codex window found\") }",
    "let x0 = (bounds[\"X\"] as? Double) ?? 0",
    "let y0 = (bounds[\"Y\"] as? Double) ?? 0",
    "let w = (bounds[\"Width\"] as? Double) ?? 1200",
    "let h = (bounds[\"Height\"] as? Double) ?? 800",
    "let pt = CGPoint(x: x0 + w * " + xRatio + ", y: y0 + h - " + yOffset + ")",
    "let src = CGEventSource(stateID: .hidSystemState)",
    "func key(_ code: CGKeyCode, flags: CGEventFlags = []) {",
    "  let d = CGEvent(keyboardEventSource: src, virtualKey: code, keyDown: true)!",
    "  d.flags = flags",
    "  d.post(tap: .cghidEventTap)",
    "  usleep(35000)",
    "  let u = CGEvent(keyboardEventSource: src, virtualKey: code, keyDown: false)!",
    "  u.flags = flags",
    "  u.post(tap: .cghidEventTap)",
    "}",
    "func mouse(_ type: CGEventType) { CGEvent(mouseEventSource: src, mouseType: type, mouseCursorPosition: pt, mouseButton: .left)?.post(tap: .cghidEventTap) }",
    "mouse(.leftMouseDown)",
    "usleep(50000)",
    "mouse(.leftMouseUp)",
    "usleep(180000)",
    "key(0, flags: [.maskCommand])",
    "usleep(50000)",
    "key(51)",
    "usleep(80000)",
    "let units = Array(text.utf16)",
    "var index = 0",
    "while index < units.count {",
    "  let end = min(index + 80, units.count)",
    "  Array(units[index..<end]).withUnsafeBufferPointer { ptr in",
    "    if let base = ptr.baseAddress, let ev = CGEvent(keyboardEventSource: src, virtualKey: 0, keyDown: true) {",
    "      ev.keyboardSetUnicodeString(stringLength: ptr.count, unicodeString: base)",
    "      ev.post(tap: .cghidEventTap)",
    "    }",
    "  }",
    "  index = end",
    "  usleep(25000)",
    "}",
    "usleep(150000)",
    "key(36)"
  ].join("\n");

  return execFilePromise("swift", ["-e", source], {
    timeout: DESKTOP_UI_SEND_TIMEOUT_MS,
    env: Object.assign({}, process.env, {
      PET_TEXT: String(text || "")
    })
  });
}

function deliverInstructionViaCodexDesktopFollower(threadId, input, text, activeTurnId, cwd) {
  if ((!CODEX_DESKTOP_FOLLOWER_DELIVERY && !CODEX_DESKTOP_FOLLOWER_FALLBACK) || !isCodexThreadId(threadId)) {
    return Promise.reject(new Error("desktop follower delivery disabled"));
  }

  if (CODEX_DESKTOP_SYNC) {
    performCodexDesktopOpen(threadId, "prepare");
  }

  return delay(DESKTOP_FOLLOWER_OPEN_DELAY_MS).then(function () {
    if (activeTurnId) {
      return waitForCodexActiveTurnToFinish(threadId, activeTurnId).then(function () {
        var startedAt = new Date().getTime();
        if (CODEX_DESKTOP_SYNC) {
          performCodexDesktopOpen(threadId, "queued-send");
        }
        return desktopFollowerStartTurn(threadId, input, cwd).then(function (delivery) {
          delivery.deliveryMethod = "desktop-queued-start";
          delivery.waitedForTurnId = activeTurnId;
          return waitForCodexUserMessage(threadId, text, startedAt).then(function () {
            return delivery;
          });
        }).catch(function (err) {
          throw markDesktopFollowerAttemptError(err, startedAt, "desktop-queued-start", activeTurnId);
        });
      });
    }
    return (function () {
      var startedAt = new Date().getTime();
      return desktopFollowerStartTurn(threadId, input, cwd).then(function (delivery) {
        return waitForCodexUserMessage(threadId, text, startedAt).then(function () {
          return delivery;
        });
      }).catch(function (err) {
        throw markDesktopFollowerAttemptError(err, startedAt, "desktop-start", "");
      });
    }());
  });
}

function waitForCodexActiveTurnToFinish(threadId, activeTurnId) {
  var deadline = new Date().getTime() + Math.max(1000, CODEX_ACTIVE_TURN_QUEUE_TIMEOUT_MS || 20 * 60 * 1000);

  if (!activeTurnId) {
    return Promise.resolve(false);
  }

  function check() {
    var row = readCodexThreadRow(threadId);
    var activity = row ? rolloutActivity(row.rollout_path) : null;

    if (!activity || !activity.lastStartAt) {
      return Promise.resolve(false);
    }

    if (activity.lastCompleteTurnId === activeTurnId) {
      return Promise.resolve(true);
    }

    if (activity.lastStartTurnId === activeTurnId && activity.lastCompleteAt >= activity.lastStartAt) {
      return Promise.resolve(true);
    }

    if (activity.lastStartTurnId !== activeTurnId && activity.lastCompleteAt >= activity.lastStartAt) {
      return Promise.resolve(true);
    }

    if (new Date().getTime() >= deadline) {
      return Promise.reject(new Error("Timed out waiting for the current Codex turn to finish before sending the queued instruction."));
    }

    return delay(1000).then(check);
  }

  return check();
}

function deliverInstructionAfterActiveTurn(threadId, task, input, text, activeTurnId, cwd) {
  if (CODEX_DESKTOP_FOLLOWER_FALLBACK || CODEX_DESKTOP_FOLLOWER_DELIVERY) {
    return deliverInstructionViaCodexDesktopFollower(threadId, input, text, activeTurnId, cwd).catch(function (desktopErr) {
      console.warn("Codex desktop follower queued delivery failed: " + friendlyDeliveryError(desktopErr));
      return confirmedDesktopFollowerAttempt(threadId, text, desktopErr).then(function (confirmedDelivery) {
        if (confirmedDelivery) {
          return confirmedDelivery;
        }
        if (CODEX_CONFIRMED_RPC_FALLBACK) {
          return deliverInstructionViaConfirmedCodexRpc(threadId, task, input, text).then(function (delivery) {
            delivery.desktopFollowerError = friendlyDeliveryError(desktopErr);
            return delivery;
          });
        }
        if (!CODEX_BACKGROUND_DELIVERY_FALLBACK) {
          throw new Error("Codex Desktop did not accept the queued instruction. Desktop fallback failed: " + friendlyDeliveryError(desktopErr));
        }
        return deliverInstructionViaCodexRpc(threadId, task, input).then(function (delivery) {
          delivery.desktopFollowerError = friendlyDeliveryError(desktopErr);
          return delivery;
        });
      });
    });
  }

  if (CODEX_CONFIRMED_RPC_FALLBACK) {
    return deliverInstructionViaConfirmedCodexRpc(threadId, task, input, text);
  }

  if (CODEX_BACKGROUND_DELIVERY_FALLBACK) {
    return deliverInstructionViaCodexRpc(threadId, task, input);
  }

  return Promise.reject(new Error("Codex Desktop queued delivery is disabled."));
}

function markDesktopFollowerAttemptError(err, startedAt, deliveryMethod, activeTurnId) {
  if (!err || typeof err !== "object") {
    err = new Error(String(err || "Desktop follower delivery failed."));
  }
  err.deliveryStartedAt = startedAt;
  err.deliveryMethod = deliveryMethod;
  err.waitedForTurnId = activeTurnId || "";
  return err;
}

function confirmedDesktopFollowerAttempt(threadId, text, err) {
  var startedAt = err && err.deliveryStartedAt ? err.deliveryStartedAt : 0;

  if (!startedAt) {
    return Promise.resolve(null);
  }

  return waitForCodexUserMessage(threadId, text, startedAt).then(function () {
    return {
      deliveryMethod: err.deliveryMethod || "desktop-start",
      threadId: threadId,
      turnId: "",
      waitedForTurnId: err.waitedForTurnId || "",
      desktopFollowerError: friendlyDeliveryError(err),
      confirmedAfterFollowerError: true
    };
  }).catch(function () {
    return null;
  });
}

function desktopFollowerStartTurn(threadId, input, cwd) {
  var turnStartParams = {
    threadId: threadId,
    input: input
  };

  if (cwd) {
    turnStartParams.cwd = cwd;
  }

  return codexDesktopIpcRequest("thread-follower-start-turn", {
    conversationId: threadId,
    turnStartParams: turnStartParams
  }, CODEX_DESKTOP_IPC_REQUEST_TIMEOUT_MS).then(function (result) {
    return desktopFollowerDeliveryResult("desktop-start", threadId, result, "");
  });
}

function desktopFollowerDeliveryResult(method, threadId, result, fallbackTurnId) {
  var body = result && result.result ? result.result : result;
  var turnId = body && body.turn && body.turn.id ? body.turn.id : fallbackTurnId || "";
  return {
    deliveryMethod: method,
    threadId: threadId,
    turnId: turnId
  };
}

function desktopIpcRouteUnavailable(err) {
  var text = err && err.message ? err.message : String(err || "");
  return /no-client-found|client-not-found|client-cannot-handle-request|request-version-mismatch|not-connected|desktop IPC|connection-closed|closed before initialize|socket not found|timeout/i.test(text);
}

function deliverInstructionToCodex(item) {
  var tasks = readBoardTasks();
  var task = findTask(tasks, item.taskId);
  var threadId = task && task.threadId ? task.threadId : item.taskId;
  var cwd;
  var desktopActiveTurnId;
  var input = [{
    type: "text",
    text: item.text,
    text_elements: []
  }];

  if (DEMO_MODE) {
    return Promise.resolve({
      deliveryMethod: "demo",
      threadId: item.taskId,
      turnId: ""
    });
  }

  if (!threadId || threadId === "current") {
    return Promise.reject(new Error("This item is not a Codex thread."));
  }

  cwd = readCodexThreadCwd(threadId);
  desktopActiveTurnId = task && task.activeTurnId ? task.activeTurnId : "";

  if (desktopActiveTurnId) {
    return deliverInstructionAfterActiveTurn(threadId, task, input, item.text, desktopActiveTurnId, cwd);
  }

  if (CODEX_DESKTOP_UI_DELIVERY) {
    return deliverInstructionViaCodexDesktopUi(threadId, item.text).catch(function (uiErr) {
      console.warn("Codex desktop UI delivery failed: " + friendlyDeliveryError(uiErr));
      if (CODEX_DESKTOP_FOLLOWER_FALLBACK) {
        return deliverInstructionViaCodexDesktopFollower(threadId, input, item.text, desktopActiveTurnId, cwd).then(function (delivery) {
          delivery.desktopUiError = friendlyDeliveryError(uiErr);
          return delivery;
        }).catch(function (desktopErr) {
          console.warn("Codex desktop follower fallback failed: " + friendlyDeliveryError(desktopErr));
          return confirmedDesktopFollowerAttempt(threadId, item.text, desktopErr).then(function (confirmedDelivery) {
            if (confirmedDelivery) {
              confirmedDelivery.desktopUiError = friendlyDeliveryError(uiErr);
              return confirmedDelivery;
            }
            if (CODEX_CONFIRMED_RPC_FALLBACK) {
              return deliverInstructionViaConfirmedCodexRpc(threadId, task, input, item.text).then(function (delivery) {
                delivery.desktopUiError = friendlyDeliveryError(uiErr);
                delivery.desktopFollowerError = friendlyDeliveryError(desktopErr);
                return delivery;
              }).catch(function (rpcErr) {
                console.warn("Codex confirmed RPC fallback failed: " + friendlyDeliveryError(rpcErr));
                if (!CODEX_BACKGROUND_DELIVERY_FALLBACK) {
                  throw new Error("Codex Desktop did not accept the instruction. UI failed: " + friendlyDeliveryError(uiErr) + " / Desktop fallback failed: " + friendlyDeliveryError(desktopErr) + " / Confirmed RPC fallback failed: " + friendlyDeliveryError(rpcErr));
                }
                return deliverInstructionViaCodexRpc(threadId, task, input).then(function (delivery) {
                  delivery.desktopUiError = friendlyDeliveryError(uiErr);
                  delivery.desktopFollowerError = friendlyDeliveryError(desktopErr);
                  delivery.confirmedRpcError = friendlyDeliveryError(rpcErr);
                  return delivery;
                });
              });
            }
            if (!CODEX_BACKGROUND_DELIVERY_FALLBACK) {
              throw new Error("Codex Desktop did not accept the instruction. UI failed: " + friendlyDeliveryError(uiErr) + " / Desktop fallback failed: " + friendlyDeliveryError(desktopErr));
            }
            return deliverInstructionViaCodexRpc(threadId, task, input).then(function (delivery) {
              delivery.desktopUiError = friendlyDeliveryError(uiErr);
              delivery.desktopFollowerError = friendlyDeliveryError(desktopErr);
              return delivery;
            });
          });
        });
      }
      if (!CODEX_BACKGROUND_DELIVERY_FALLBACK) {
        throw new Error("Codex Desktop did not accept the instruction: " + friendlyDeliveryError(uiErr));
      }
      return deliverInstructionViaCodexRpc(threadId, task, input).then(function (delivery) {
        delivery.desktopUiError = friendlyDeliveryError(uiErr);
        return delivery;
      });
    });
  }

  if (CODEX_DESKTOP_FOLLOWER_DELIVERY) {
    return deliverInstructionViaCodexDesktopFollower(threadId, input, item.text, desktopActiveTurnId, cwd).catch(function (desktopErr) {
      console.warn("Codex desktop follower delivery skipped: " + friendlyDeliveryError(desktopErr));
      return confirmedDesktopFollowerAttempt(threadId, item.text, desktopErr).then(function (confirmedDelivery) {
        if (confirmedDelivery) {
          return confirmedDelivery;
        }
        return deliverInstructionViaCodexRpc(threadId, task, input).then(function (delivery) {
          delivery.desktopFollowerError = friendlyDeliveryError(desktopErr);
          return delivery;
        });
      });
    });
  }

  if (CODEX_CONFIRMED_RPC_FALLBACK) {
    return deliverInstructionViaConfirmedCodexRpc(threadId, task, input, item.text);
  }

  if (CODEX_BACKGROUND_DELIVERY_FALLBACK) {
    return deliverInstructionViaCodexRpc(threadId, task, input);
  }

  return Promise.reject(new Error("Codex Desktop delivery is disabled."));
}

function instructionTargetsActiveTurn(item) {
  var tasks = readBoardTasks();
  var task = findTask(tasks, item.taskId);
  return !!(task && task.activeTurnId);
}

function deliverInstructionInBackground(item) {
  setTimeout(function () {
    deliverInstructionToCodex(item).then(function (delivery) {
      applyInstructionDeliverySuccess(item, delivery);
    }).catch(function (deliveryErr) {
      applyInstructionDeliveryFailure(item, deliveryErr);
    });
  }, 0);
}

function applyInstructionDeliverySuccess(item, delivery) {
  var threadId = delivery.threadId || threadIdForInstruction(item);
  var syncOptions = desktopSyncOptionsForDelivery(delivery);
  var desktopSync = openCodexDesktopThread(threadId, "sent", syncOptions);
  var sent = updateInstructionDelivery(item.id, {
    status: "sent",
    delivery: "sent",
    deliveryMethod: delivery.deliveryMethod,
    deliveryError: "",
    turnId: delivery.turnId
  }) || item;

  invalidateRecentCodexCache();
  watchCodexTurnForDesktopSync(threadId, delivery.turnId, syncOptions);
  return {
    threadId: threadId,
    desktopSync: desktopSync,
    instruction: sent
  };
}

function desktopSyncOptionsForDelivery(delivery) {
  var method = delivery && delivery.deliveryMethod ? String(delivery.deliveryMethod) : "";
  return {
    forceRefresh: DESKTOP_SYNC_FALLBACK_FORCE_REFRESH && !!method && method !== "desktop-ui" && method !== "demo"
  };
}

function applyInstructionDeliveryFailure(item, deliveryErr) {
  var detail = friendlyDeliveryError(deliveryErr);
  var failed = updateInstructionDelivery(item.id, {
    status: "failed",
    delivery: "failed",
    deliveryError: detail
  }) || item;

  invalidateRecentCodexCache();
  return {
    detail: detail,
    permissionRequired: deliveryErrorNeedsPermission(deliveryErr),
    permission: remoteControlPermissionStatus(),
    instruction: failed
  };
}

function deliverInstructionViaConfirmedCodexRpc(threadId, task, input, text) {
  var startedAt = new Date().getTime();
  return deliverInstructionViaCodexRpc(threadId, task, input).then(function (delivery) {
    delivery.deliveryMethod = delivery.deliveryMethod === "queued-start" ? "codex-rpc-queued-start" : "codex-rpc-start";
    return waitForCodexUserMessage(threadId, text, delivery.startedAt || startedAt).then(function () {
      return delivery;
    });
  });
}

function deliverInstructionViaCodexRpc(threadId, task, input) {
  return ensureCodexRpcClient().then(function (client) {
    return client.request("thread/resume", {
      threadId: threadId
    }, CODEX_DELIVERY_TIMEOUT_MS).then(function (resumeResult) {
      var activeTurnId = activeTurnIdForDelivery(task, resumeResult);
      if (activeTurnId) {
        return waitForCodexActiveTurnToFinish(threadId, activeTurnId).then(function () {
          return startCodexTurn(client, threadId, input, "queued-start").then(function (delivery) {
            delivery.waitedForTurnId = activeTurnId;
            return delivery;
          });
        });
      }
      return startCodexTurn(client, threadId, input);
    });
  });
}

function startCodexTurn(client, threadId, input, deliveryMethod) {
  var startedAt = new Date().getTime();
  return client.request("turn/start", {
    threadId: threadId,
    input: input
  }, CODEX_DELIVERY_TIMEOUT_MS).then(function (result) {
    return {
      deliveryMethod: deliveryMethod || "start",
      threadId: threadId,
      turnId: result && result.turn ? result.turn.id : "",
      startedAt: startedAt
    };
  });
}

function activeTurnIdForDelivery(task, resumeResult) {
  var turns;
  var i;

  if (task && task.activeTurnId) {
    return task.activeTurnId;
  }

  turns = resumeResult && resumeResult.thread && resumeResult.thread.turns;
  if (Array.isArray(turns)) {
    for (i = turns.length - 1; i >= 0; i -= 1) {
      if (turns[i] && turns[i].status === "inProgress" && turns[i].id) {
        return turns[i].id;
      }
    }
  }

  return "";
}

function friendlyDeliveryError(err) {
  var text = err && err.message ? err.message : String(err || "Send failed.");
  text = text.replace(/\s+/g, " ").trim();
  if (deliveryErrorNeedsPermission(text)) {
    return "Mac approval is needed. Approve the macOS or Codex prompt on this Mac, then try again. For visible Desktop UI delivery, allow Blinky Codex ScreenPet.app in Privacy & Security > Accessibility.";
  }
  if (text.length > 180) {
    text = text.slice(0, 179) + "...";
  }
  return text || "Send failed.";
}

function deliveryErrorNeedsPermission(err) {
  var text = String(err && err.message ? err.message : err || "").toLowerCase();
  return text.indexOf("accessibility") !== -1 ||
    text.indexOf("not authorized") !== -1 ||
    text.indexOf("not permitted") !== -1 ||
    text.indexOf("operation not permitted") !== -1 ||
    text.indexOf("file access") !== -1 ||
    text.indexOf("folder access") !== -1 ||
    text.indexOf("access local") !== -1 ||
    text.indexOf("would like to access") !== -1 ||
    text.indexOf("event tap") !== -1 ||
    text.indexOf("cgevent") !== -1 ||
    text.indexOf("privacy") !== -1 ||
    text.indexOf("tcc") !== -1;
}

function handleApi(req, res, pathname, parsedUrl) {
  if (pathname === "/api/setup" && req.method === "GET") {
    if (!isLocalRequest(req)) {
      sendJson(res, 403, {
        error: "Setup is only available on this Mac.",
        setupUrl: "http://localhost:" + PORT + "/setup"
      });
      return true;
    }

    sendJson(res, 200, setupInfo(req));
    return true;
  }

  if (pathname === "/api/setup/password" && req.method === "POST") {
    if (!isLocalRequest(req)) {
      sendJson(res, 403, {
        error: "Phone password can only be changed on this Mac."
      });
      return true;
    }

    readBody(req, function (err, body) {
      var result;
      if (err) {
        sendJson(res, 400, { error: "Invalid request body" });
        return;
      }

      result = setLocalAuthPin(body && (body.pin || body.password));
      if (!result.ok) {
        sendJson(res, result.status || 400, { error: result.error || "Could not update phone password." });
        return;
      }

      sendJson(res, 200, {
        ok: true,
        auth: result.auth,
        setup: setupInfo(req)
      });
    });
    return true;
  }

  if (pathname === "/api/setup/remote" && req.method === "POST") {
    if (!isLocalRequest(req)) {
      sendJson(res, 403, {
        error: "Remote access settings can only be changed on this Mac."
      });
      return true;
    }

    readBody(req, function (err, body) {
      var result;
      if (err) {
        sendJson(res, 400, { error: "Invalid request body" });
        return;
      }

      result = setManualTunnelUrl(body && (body.url || body.manualTunnelUrl));
      if (!result.ok) {
        sendJson(res, result.status || 400, { error: result.error || "Could not save remote URL." });
        return;
      }

      sendJson(res, 200, {
        ok: true,
        url: result.url,
        setup: setupInfo(req)
      });
    });
    return true;
  }

  if (pathname === "/api/setup/permissions/open" && req.method === "POST") {
    if (!isLocalRequest(req)) {
      sendJson(res, 403, {
        error: "Permission settings can only be opened on this Mac."
      });
      return true;
    }

    var opened = openRemoteControlPermissionSettings();
    remoteControlPermissionCache.checkedAt = 0;
    sendJson(res, opened ? 200 : 500, {
      ok: opened,
      permission: remoteControlPermissionStatus()
    });
    return true;
  }

  if (pathname === "/api/auth/status" && req.method === "GET") {
    sendJson(res, 200, {
      auth: authPublicState(pinMatches(requestPin(req))),
      updatedAt: new Date().toISOString()
    });
    return true;
  }

  if (pathname === "/api/auth/unlock" && req.method === "POST") {
    readBody(req, function (err, body) {
      var pin;
      if (err) {
        sendJson(res, 400, { error: "Invalid request body" });
        return;
      }

      pin = body && body.pin ? String(body.pin) : "";
      if (!pinMatches(pin)) {
        sendJson(res, 401, {
          error: "Invalid PIN",
          authRequired: true,
          auth: authPublicState(false)
        });
        return;
      }

      sendJson(res, 200, {
        ok: true,
        auth: authPublicState(true)
      });
    });
    return true;
  }

  if (pathname.indexOf("/api/") !== 0) {
    return false;
  }

  if (!requireApiAuth(req, res)) {
    return true;
  }

  if (pathname === "/api/tasks" && req.method === "GET") {
    taskBoardAsync(req).then(function (board) {
      sendJson(res, 200, board);
    }).catch(function () {
      sendJson(res, 200, taskBoard(req));
    });
    return true;
  }

  if (pathname === "/api/tasks" && req.method === "POST") {
    readBody(req, function (err, body) {
      if (err) {
        sendJson(res, 400, { error: "Invalid request body" });
        return;
      }

      upsertTask(body);
      sendJson(res, 200, taskBoard(req));
    });
    return true;
  }

  if (pathname === "/api/task" && req.method === "GET") {
    upsertTask(parsedUrl.query || {});
    sendJson(res, 200, taskBoard(req));
    return true;
  }

  if (pathname === "/api/tasks/reset" && (req.method === "POST" || req.method === "GET")) {
    writeTasks([]);
    writeStatus(defaultStatus);
    sendJson(res, 200, taskBoard(req));
    return true;
  }

  if (pathname === "/api/instructions" && req.method === "GET") {
    sendJson(res, 200, {
      instructions: filteredInstructions(parsedUrl.query || {}),
      updatedAt: new Date().toISOString()
    });
    return true;
  }

  if (pathname === "/api/instructions" && req.method === "POST") {
    readBody(req, function (err, body) {
      var item;
      var queued;
      if (err) {
        sendJson(res, 400, { error: "Invalid request body" });
        return;
      }

      item = addInstruction(body || {});
      if (!item) {
        sendJson(res, 400, { error: "Instruction text is required" });
        return;
      }

      if (instructionTargetsActiveTurn(item)) {
        queued = updateInstructionDelivery(item.id, {
          status: "queued",
          delivery: "queued",
          deliveryMethod: "waiting-active-turn",
          deliveryError: "",
          turnId: ""
        }) || item;
        invalidateRecentCodexCache();
        sendJson(res, 202, {
          delivery: "queued",
          instruction: queued,
          board: taskBoard(req)
        });
        deliverInstructionInBackground(queued);
        return;
      }

      deliverInstructionToCodex(item).then(function (delivery) {
        var result = applyInstructionDeliverySuccess(item, delivery);
        sendJson(res, 200, {
          delivery: "sent",
          desktopSync: result.desktopSync ? "opened" : "skipped",
          instruction: result.instruction,
          board: taskBoard(req)
        });
      }).catch(function (deliveryErr) {
        var result = applyInstructionDeliveryFailure(item, deliveryErr);
        sendJson(res, 502, {
          error: "Send failed",
          detail: result.detail,
          permissionRequired: result.permissionRequired,
          permission: result.permission,
          instruction: result.instruction,
          board: taskBoard(req)
        });
      });
    });
    return true;
  }

  if (pathname === "/api/instructions/ack" && req.method === "POST") {
    readBody(req, function (err, body) {
      var item;
      if (err) {
        sendJson(res, 400, { error: "Invalid request body" });
        return;
      }

      item = markInstruction(body || {});
      if (!item) {
        sendJson(res, 404, { error: "Instruction not found" });
        return;
      }

      sendJson(res, 200, {
        instruction: item,
        board: taskBoard(req)
      });
    });
    return true;
  }

  if (pathname === "/api/status" && req.method === "GET") {
    sendJson(res, 200, statusFromTasks(readBoardTasks()));
    return true;
  }

  if (pathname === "/api/status" && req.method === "POST") {
    readBody(req, function (err, body) {
      if (err) {
        sendJson(res, 400, { error: "Invalid request body" });
        return;
      }

      var next = normalizeStatus(body, true);
      writeStatus(next);
      upsertTask({
        id: body.id || "current",
        state: next.state,
        title: next.task,
        message: next.message,
        detail: next.detail,
        progress: next.progress
      });
      sendJson(res, 200, next);
    });
    return true;
  }

  if (pathname === "/api/set" && req.method === "GET") {
    var next = normalizeStatus(parsedUrl.query || {}, true);
    writeStatus(next);
    upsertTask({
      id: parsedUrl.query.id || "current",
      state: next.state,
      title: next.task,
      message: next.message,
      detail: next.detail,
      progress: next.progress
    });
    sendJson(res, 200, next);
    return true;
  }

  if (pathname === "/api/reset" && (req.method === "POST" || req.method === "GET")) {
    var reset = normalizeStatus({
      state: "idle",
      title: "Blinky Codex ScreenPet",
      task: "Waiting for task",
      message: "Ready",
      detail: "Blinky watches your Codex tasks blink by blink.",
      progress: 0
    }, true);
    writeStatus(reset);
    sendJson(res, 200, reset);
    return true;
  }

  return false;
}

var server = http.createServer(function (req, res) {
  var parsedUrl = parseRequestUrl(req);
  var pathname = decodeURIComponent(parsedUrl.pathname || "/");

  if (handleApi(req, res, pathname, parsedUrl)) {
    return;
  }

  if (pathname === "/control") {
    serveStatic(req, res, "/control.html");
    return;
  }

  if (pathname === "/setup" || pathname === "/setup.html") {
    if (!isLocalRequest(req)) {
      sendSetupLocalOnly(res);
      return;
    }
    serveStatic(req, res, "/setup.html");
    return;
  }

  serveStatic(req, res, pathname);
});

readStatus();

server.listen(PORT, HOST, function () {
  var addresses = localAddresses();
  var auth = authConfig();
  markStartupQueuedInstructionsFailed();
  resumeStartupQueuedInstructions();
  console.log("Blinky Codex ScreenPet is running.");
  if (DEMO_MODE) {
    console.log("Demo mode: ON (fake tasks; real Codex data is not read).");
  }
  if (auth.enabled) {
    if (auth.source === "env") {
      console.log("PIN:     configured with PET_AUTH_PIN.");
    } else {
      console.log("PIN:     " + auth.pin + " (stored locally in data/auth.json)");
    }
  } else {
    console.log("PIN:     disabled with PET_AUTH=0.");
  }
  console.log("Setup:   http://localhost:" + PORT + "/setup");
  console.log("Mac:     http://127.0.0.1:" + PORT + "/");
  if (addresses.length) {
    addresses.forEach(function (address) {
      console.log("iPhone:  http://" + address + ":" + PORT + "/");
    });
  } else {
    console.log("iPhone:  http://<your-mac-ip>:" + PORT + "/");
  }
});
