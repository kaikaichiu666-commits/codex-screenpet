"use strict";

var childProcess = require("child_process");
var fs = require("fs");
var os = require("os");
var path = require("path");

var ROOT = path.resolve(__dirname, "..");
var PORT = String(process.env.PORT || "8788");
var CODEX_STATE_DB = process.env.CODEX_STATE_DB ||
  path.join(os.homedir(), ".codex", "state_5.sqlite");
var CODEX_LOGS_DB = process.env.CODEX_LOGS_DB ||
  path.join(os.homedir(), ".codex", "logs_2.sqlite");

function run(command, args) {
  try {
    return childProcess.execFileSync(command, args, {
      encoding: "utf8",
      stdio: ["ignore", "pipe", "ignore"]
    }).trim();
  } catch (err) {
    return "";
  }
}

function mark(ok) {
  return ok ? "OK  " : "WARN";
}

function line(label, ok, detail) {
  var suffix = detail ? " - " + detail : "";
  console.log(mark(ok) + " " + label + suffix);
}

function exists(relativePath) {
  return fs.existsSync(path.join(ROOT, relativePath));
}

function nodeIsNewEnough() {
  var major = Number(process.versions.node.split(".")[0]);
  return major >= 18;
}

function serverProcessDetail() {
  return run("lsof", ["-nP", "-iTCP:" + PORT, "-sTCP:LISTEN"]);
}

function printUrls(tailscaleIp) {
  console.log("");
  console.log("Useful URLs");
  console.log("- Setup:    http://localhost:" + PORT + "/setup");
  console.log("- Local:     http://localhost:" + PORT + "/");
  console.log("- Control:   http://127.0.0.1:" + PORT + "/control");
  if (tailscaleIp) {
    console.log("- Tailscale: http://" + tailscaleIp.split(/\s+/)[0] + ":" + PORT + "/");
  } else {
    console.log("- Tailscale: run `tailscale ip -4`, then open http://TAILSCALE-IP:" + PORT + "/");
  }
}

function firstIpv4(value) {
  var match = String(value || "").match(/\b(?:\d{1,3}\.){3}\d{1,3}\b/);
  return match ? match[0] : "";
}

console.log("Blinky Codex ScreenPet Doctor");
console.log("");

line("Node.js >= 18", nodeIsNewEnough(), process.version);
line("Project root", fs.existsSync(ROOT), ROOT);
line("server.js", exists("server.js"), "local server entry");
line("public/index.html", exists("public/index.html"), "mobile dashboard");
line("public/pet.js", exists("public/pet.js"), "mobile dashboard logic");
line("public/styles.css", exists("public/styles.css"), "responsive mobile UI");
line("public/setup.html", exists("public/setup.html"), "first-run setup page");
line("Start launcher", exists("Start Blinky Codex ScreenPet.command"), "macOS double-click launcher");
line("data/.gitkeep", exists("data/.gitkeep"), "runtime data folder placeholder");
line("Codex state DB", fs.existsSync(CODEX_STATE_DB), CODEX_STATE_DB);
line("Codex logs DB", fs.existsSync(CODEX_LOGS_DB), CODEX_LOGS_DB);

var server = serverProcessDetail();
line("Port " + PORT, Boolean(server), server ? "server is listening" : "not listening right now");

var tailscaleIp = firstIpv4(run("tailscale", ["ip", "-4"]));
line("Tailscale IPv4", Boolean(tailscaleIp), tailscaleIp || "not available or not logged in");

printUrls(tailscaleIp);

console.log("");
console.log("Checks to run before publishing");
console.log("- npm run check");
console.log("- npm run prepare-export");
